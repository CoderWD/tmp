from yt_dlp import YoutubeDL
import os
import sys
import json
import tempfile


def make_cache_dir(library_path):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if not library_path:
        cache_dir = os.path.join(current_dir, ".cache")
    else:
        cache_dir = os.path.join(library_path, ".cache")

    # 判断目录是否存在
    if not os.path.exists(cache_dir):
        # 如果目录不存在，创建目录
        os.makedirs(cache_dir)
        # 设置权限为可读写（仅当前用户）
        os.chmod(cache_dir, 0o700)
        print(f"cache dir '{cache_dir}' created.")
    else:
        print(f"cache dir '{cache_dir}' already exists.")

    return cache_dir


def create_cookies_file(cookie_str, cache_dir):
    """
    创建临时 cookies 文件用于 yt-dlp
    参数:
        cookie_str: Netscape 格式的 cookie 字符串
        cache_dir: 缓存目录路径
    返回:
        cookies 文件路径，如果失败返回 None
    """
    # 检查输入是否为空
    if not cookie_str.strip():
        print("Cookie 字符串为空")
        return None
    
    lines = cookie_str.strip().splitlines()
    
    # 检查是否为有效的 Netscape 格式
    if len(lines) < 2:
        print("Cookie 格式无效：行数不足")
        return None
    
    # 检查第一行是否为 Netscape 头部
    if lines[0].strip() != "# Netscape HTTP Cookie File":
        print("Cookie 格式无效：缺少 Netscape 头部")
        return None
    
    try:
        # 创建 cookies 文件路径
        cookies_file_path = os.path.join(cache_dir, "cookies.txt")
        
        # 写入 cookies 文件
        with open(cookies_file_path, 'w', encoding='utf-8') as f:
            f.write(cookie_str)
        
        print(f"Cookies 文件已创建: {cookies_file_path}")
        return cookies_file_path
        
    except Exception as e:
        print(f"创建 cookies 文件失败: {e}")
        return None


def process_cookie(cookie_str):
    """
    保留原有的处理方法作为备用（已废弃使用）
    """
    # 检查输入是否为空或只有一行
    if not cookie_str.strip() or len(cookie_str.splitlines()) <= 1:
        return ""  # 输出空字符串
    else:
        # 分割字符串为行，忽略第一行
        lines = cookie_str.splitlines()[1:]

        # 初始化 cookie 字符串
        cookie_string = ""

        # 遍历每一行并提取 key 和 value
        for line in lines:
            parts = line.split("\t")
            if len(parts) >= 3:  # 保证有至少 3 个部分
                key = parts[-2]  # 倒数第二个是 key
                value = parts[-1]  # 倒数第一个是 value
                cookie_string += f"{key}={value}; "

        # 去掉最后一个多余的分号和空格
        cookie_string = cookie_string.strip("; ")
        return cookie_string


def isCookieLangEnRegion(cookie_string_or_file):
    """
    检查 cookies 中是否设置了英文区域
    参数:
        cookie_string_or_file: cookie 字符串或 Netscape 格式的 cookie 内容
    """
    cookie_content = ""
    
    # 如果输入为空，返回 False
    if not cookie_string_or_file:
        return False
    
    # 判断是否为 Netscape 格式（多行且包含头部）
    if '\n' in cookie_string_or_file and "# Netscape HTTP Cookie File" in cookie_string_or_file:
        # 解析 Netscape 格式
        lines = cookie_string_or_file.strip().splitlines()
        for line in lines:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split('\t')
            if len(parts) >= 6:  # Netscape 格式至少有 6 列
                name = parts[5] if len(parts) > 5 else parts[-2]
                value = parts[6] if len(parts) > 6 else parts[-1]
                if name == 'custom_lang':
                    return value.startswith('en')
    else:
        # 当作普通 cookie 字符串处理
        cookies = cookie_string_or_file.split(';')
        for cookie in cookies:
            cookie = cookie.strip()  # 移除空白字符
            if cookie.startswith('custom_lang='):
                # 提取语言值
                lang_value = cookie[12:]  # 去掉 'custom_lang=' 前缀
                # 检查是否以 'en' 开头
                return lang_value.startswith('en')

    return False


def read_language_cache():
    # 获取当前文件所在的目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, ".cache_lang")

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            print(f'lang cache is: {content}')
        return content
    except FileNotFoundError:
        print(".cache_lang not exists")
        return None
    except Exception as e:
        print(f'read language cache error: {str(e)}')
        return None


def extract(url, cookie_str, json_param_str, library_path):
    print(f"extract from python: {url}")
    print(f"param: {json_param_str}")
    print(f"cookie: {cookie_str}")
    result = ""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 遍历当前目录及其所有子目录
        for root, dirs, files in os.walk(current_dir):
            if root not in sys.path:  # 避免重复添加
                sys.path.append(root)

        cache_dir = make_cache_dir(library_path)
        
        # 创建 cookies 文件
        cookies_file_path = create_cookies_file(cookie_str, cache_dir)
        
        # 15秒超时时间
        socket_timeout = 15

        format_selector = (
            "bv*[height<=1080]"
        )

        # 配置下载选项，只解析不下载
        ydl_opts = {
            'socket_timeout': socket_timeout,
            'format': format_selector,
            'quiet': True,  # 禁用其他输出
            'dumpjson': True,  # 输出解析后的 JSON 数据
            'cachedir': cache_dir,  # 设置缓存目录为当前脚本所在目录
            'noplaylist': True,  # 仅处理单个视频，不处理播放列表
        }
        
        # 如果成功创建了 cookies 文件，则添加到配置中
        if cookies_file_path:
            ydl_opts['cookiefile'] = cookies_file_path
            print(f"使用 cookies 文件: {cookies_file_path}")
        else:
            print("警告: 无法创建 cookies 文件，将不使用 cookies")
            # 作为备用方案，仍然使用旧的方法
            cookie_string = process_cookie(cookie_str)
            if cookie_string:
                ydl_opts['http_headers'] = {
                    'Cookie': cookie_string,
                }
                print(f"备用方案：使用 http_headers 传递 cookies")

        # 检查是否为英文区域
        is_english_region = isCookieLangEnRegion(cookie_str)

        # 执行解析，获取下载链接
        with YoutubeDL(ydl_opts) as ydl:
            try:
                info_dict = ydl.extract_info(url, download=False)  # 提取信息而不下载
                # for format_info in info_dict.get('formats', []):
                #     print(format_info)

                print(f"is_english_region: {is_english_region}")
                # 处理音频格式的语言过滤
                if info_dict and is_english_region and 'formats' in info_dict and info_dict['formats']:
                    formats = info_dict['formats']

                    # 分离音频格式和其他格式
                    audio_formats = []
                    other_formats = []

                    for format_info in formats:
                        # 判断是否为音频格式：有audio_ext但没有video_ext
                        audio_ext = format_info.get('audio_ext')
                        video_ext = format_info.get('video_ext')
                        language = format_info.get('language')
                        # print(f"audio_ext: {audio_ext}, video_ext: {video_ext}, language: {language}")

                        # 添加详细的调试信息
                        has_audio_ext = format_info.get('audio_ext') is not None and str(format_info.get('audio_ext')).lower() != 'none'
                        has_video_ext = format_info.get('video_ext') is not None and str(format_info.get('video_ext')).lower() != 'none'
                        # print(f"has_audio_ext: {has_audio_ext}, has_video_ext: {has_video_ext}, language: {language}")

                        if has_audio_ext and not has_video_ext:
                            audio_formats.append(format_info)
                        else:
                            other_formats.append(format_info)

                    # 检查音频格式中是否有英文语言
                    en_audio_formats = []
                    has_en_audio = False

                    for audio_format in audio_formats:
                        language = audio_format.get('language')
                        if language and language.startswith('en'):
                            en_audio_formats.append(audio_format)
                            has_en_audio = True

                    # 如果检测到英文音频格式，则只保留英文音频，其他格式不变
                    if has_en_audio:
                        # 重新组合格式列表：其他格式 + 英文音频格式
                        filtered_formats = other_formats + en_audio_formats
                        info_dict['formats'] = filtered_formats
                        print(f"Filtered audio formats: kept {len(en_audio_formats)} English audio formats out of {len(audio_formats)} total audio formats")
                    else:
                        print("No English audio formats found, keeping all original formats")

                # 输出所有格式的下载链接
                result = json.dumps(info_dict, indent=4)
                if info_dict and 'formats' in info_dict:
                    for format_info in info_dict['formats']:
                        print(format_info)

            except Exception as e:
                # 异常处理代码
                print(f"An error occurred: {e}")
                result = json.dumps({"url": url, "errMsg": str(e)})
            finally:
                # 清理临时 cookies 文件
                if cookies_file_path and os.path.exists(cookies_file_path):
                    try:
                        os.remove(cookies_file_path)
                        print(f"清理临时 cookies 文件: {cookies_file_path}")
                    except Exception as cleanup_error:
                        print(f"清理 cookies 文件失败: {cleanup_error}")
                        
    except Exception as e:
        print(f"Error: {e}")
        result = json.dumps({"url": url, "errMsg": str(e)})
        # 确保在异常情况下也清理文件
        if 'cookies_file_path' in locals() and cookies_file_path and os.path.exists(cookies_file_path):
            try:
                os.remove(cookies_file_path)
                print(f"异常情况下清理临时 cookies 文件: {cookies_file_path}")
            except Exception as cleanup_error:
                print(f"异常情况下清理 cookies 文件失败: {cleanup_error}")

    return result


if __name__ == '__main__':
    url = "https://www.youtube.com/watch?v=T4SimnaiktU"
    # 测试用的 Netscape 格式 cookie 字符串（示例）
    cookie_str = """# Netscape HTTP Cookie File
.youtube.com	TRUE	/	TRUE	1755957256	GPS	1
.youtube.com	TRUE	/	TRUE	1771507653	VISITOR_INFO1_LIVE	7peeLVjnl9Q
m.youtube.com	FALSE	/	FALSE	0	custom_lang	zh-Hans-CN"""
    
    print("=== 测试新的 cookies 文件实现 ===")
    result = extract(url, cookie_str, "", None)
    if result:
        print("提取成功!")
    else:
        print("提取失败或无结果")
