"""识别 yt-dlp 发起的 ffmpeg / ffprobe 命令。"""

from __future__ import annotations

import os


_FFMPEG_NAMES = frozenset({
    'ffmpeg',
    'ffprobe',
    'avconv',
    'avprobe',
})


def normalize_program_name(name: str) -> str:
    base = os.path.basename(str(name or '')).lower()
    if base.endswith('.exe'):
        base = base[:-4]
    return base


def is_ffmpeg_program(program: str) -> bool:
    base = normalize_program_name(program)
    if base in _FFMPEG_NAMES:
        return True
    return base.startswith('ffmpeg') or base.startswith('ffprobe')
