"""Swift ↔ Python FFmpeg 执行桥接。

Swift 通过 `register_runner` 注入基于 FFmpegKit 的执行器；
subprocess hook 将 ffmpeg / ffprobe 命令转交此模块。
"""

from __future__ import annotations

import errno

from ios_debug_log import log, log_preview

_RUNNER = None


def register_runner(runner) -> None:
    """注册执行器：runner(argv, stdin_data) -> (stdout, stderr, returncode)。"""
    global _RUNNER
    if runner is None or not callable(runner):
        raise TypeError('runner must be callable')
    _RUNNER = runner
    log('ffmpeg_bridge', 'Swift FFmpeg runner registered')


def unregister_runner() -> None:
    global _RUNNER
    _RUNNER = None
    log('ffmpeg_bridge', 'Swift FFmpeg runner unregistered')


def is_bridge_available() -> bool:
    return _RUNNER is not None


def execute_via_bridge(argv, stdin_data=None) -> tuple[str, str, int]:
    if _RUNNER is None:
        raise OSError(
            errno.ENOENT,
            'Swift FFmpeg runner not registered. '
            'FFmpeg bridge not registered. Embed ffmpeg-kit in the host app.',
        )

    argv_list = [str(part) for part in argv]
    stdin_text = ''
    if stdin_data is not None:
        stdin_text = (
            stdin_data.decode('utf-8', errors='replace')
            if isinstance(stdin_data, bytes)
            else str(stdin_data)
        )

    log('ffmpeg_bridge', f'execute argv0={argv_list[0] if argv_list else "?"} argc={len(argv_list)}')
    if len(argv_list) > 1:
        log_preview('ffmpeg_bridge', 'argv tail', ' '.join(argv_list[1:]), limit=320)

    result = _RUNNER(argv_list, stdin_text)
    if not isinstance(result, (list, tuple)) or len(result) < 3:
        raise RuntimeError('FFmpeg runner must return (stdout, stderr, returncode)')

    stdout = str(result[0] or '')
    stderr = str(result[1] or '')
    returncode = int(result[2])
    log(
        'ffmpeg_bridge',
        f'done returncode={returncode} stdout_len={len(stdout)} stderr_len={len(stderr)}',
    )
    return stdout, stderr, returncode
