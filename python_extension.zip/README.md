# python_extension

iOS 真机嵌入式 Python 上的 **yt-dlp 适配层**。由 `OfflineUltra` 的 `PythonMediaExtractor` 经 Firebase Remote Config（key：`python_extension`）下载 zip，解包到 `~/Library/python_scripts/python_extension`。沙盒内目录结构与本仓库本目录一致。

### Remote Config（`python_extension`）

```json
{
  "version": "2026.06.09+scripts-966451641361",
  "resourceUrl": "https://example.com/python_extension.zip"
}
```

仅这两个字段：`version` 与本地缓存不一致则重新下载；`resourceUrl` 为 zip 地址。旧 key `yt_dlp_extension` / `pythonExtractorConfig` 不再读取。

| 路径 | 可否修改 | 说明 |
|------|----------|------|
| [`yt_dlp/`](./yt_dlp/) | **禁止** | 上游 yt-dlp 源码镜像；升级请整体替换，勿 patch |
| 根目录 `ios_*.py`、`extract_media.py`、`download_media.py` | 可以 | iOS 环境 hook / 桥接 / 调用入口 |
| [`ejs/`](./ejs/) | 按需 | YouTube EJS solver 资源（配合 `ios_ejs_hook`） |
| `VERSION` | 可以 | 脚本包版本标识 |

## Swift 调用约定

| Swift | Python 模块 / 函数 | 成功返回 | 失败返回 |
|-------|-------------------|----------|----------|
| `PythonMediaExtractor.extract` | `extract_media.extract(url, cookie_str, json_param, library_path)` | yt-dlp `info` JSON（`ExtractorMedia` 可解码） | `{"url","errMsg"}` |
| `PythonMediaExtractor.search` | `extract_media.search(...)` | `{query,search_type,entries}` | 同上 |
| `PythonMediaExtractor.checkURLSupport` | `extract_media.check_url_support(url)` | `{ok, supported, extractor}`（不联网） | `supported=false` |
| （下载扩展） | `download_media.download(...)` | `{ok, …}` | `{ok:false, error}` |

初始化时 Swift 会：

1. 把脚本根目录插入 `sys.path`
2. `ios_js_bridge.register_runner` → JavaScriptCore（EJS / node 假运行时）
3. 解析阶段由 `extract_media` 自行 `force` 安装 subprocess / ejs hook

## Cookie

```text
WKWebView CookieStore
  → MediaExtractor.getCookies（Netscape 文本）
  → extract_media / download_media
  → ios_cookies.apply_cookies_to_ydl_opts
       ├─ 优先写唯一临时 cookiefile（yt-dlp cookiefile）
       └─ 无法规范化时回退 http_headers.Cookie
```

`ios_cookies` 接受：标准 Netscape、无表头 tab 行、或 `a=b; c=d`（有 URL 时可合成 Netscape）。

`extract_media.extract` 成功 JSON 附带顶层 `cookie_header`（优先 YoutubeDL cookiejar，再 cookiefile / 入参），供 Swift progressive / HLS 下载复用；sanitize 会去掉 format 内 Cookie。

## 格式可达性探测（`ios_format_probe`）

`_sanitize_format_for_ios` 会补齐 `url/ext/protocol/resolution`，并透传 `height`、`filesize` / `filesize_approx`，供 Swift 清晰度列表展示。

`extract` / `extract_full` 在返回前并发探测 format URL，剔除 HTTP **403/404/410/451**：

- **progressive**（含 `googlevideo.com/videoplayback`）：轻量 GET 读少量字节（**不用** Range，避免单独误报）
- **HLS**：拉 manifest；若是 master 则跟进第一条 variant；再对 media playlist **只抽检一个分片**（不必全量校验）
- 日志前缀：`[YTDLP-iOS][format_probe]`

## 层次

```text
Swift PythonMediaExtractor
  └─ extract_media / download_media   ← 业务入口（先装 hook，再调 yt_dlp）
        ├─ ios_cookies                ← Cookie 规范化
        ├─ ios_format_probe           ← 剔 403 等；HLS 抽检一个分片
        ├─ ios_subprocess_hook        ← 禁止 fork；JS/ffmpeg 转桥接
        ├─ ios_ejs_hook / ios_js_*    ← JavaScriptCore
        ├─ ios_ffmpeg_*               ← FFmpegKit
        ├─ ios_download_* / progress  ← 后台 URLSession / 进度
        └─ yt_dlp/                    ← 只读上游
```

## Agent / 开发约定

1. **绝不**编辑、格式化、顺手重构 `yt_dlp/` 内任何文件。
2. iOS 能力不足（无子进程、无 node/ffmpeg 二进制等）→ 只改根目录 hook / 入口 / 桥接。
3. 升级 yt-dlp：整树替换 `yt_dlp/`，再回归 hook 与入口；勿在上游内打本地补丁。
4. **调试日志**：改 hook / 入口时须用 [`ios_debug_log.py`](./ios_debug_log.py)（`log` / `log_preview` / `log_timing`），前缀 `[YTDLP-iOS][category]`；失败响应保留 `debug_log` 回传 Swift。详见 [`OfflineUltra/README.md`「调试日志规范」](../OfflineUltra/README.md#调试日志规范) 与 [`.cursor/rules/05-debug-logging.mdc`](../.cursor/rules/05-debug-logging.mdc)。
5. 行为变更时同步：本 README、仓库根 [`README.md`](../README.md)、[`OfflineUltra/README.md`](../OfflineUltra/README.md)、[`.kiro/steering/`](../OfflineUltra/.kiro/steering/)。
