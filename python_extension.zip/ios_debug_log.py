"""iOS yt-dlp 调试日志：写入 stderr 并缓存在内存，供 extract_media 回传。"""

from __future__ import annotations

import sys
import time

_LOGS: list[str] = []
_ENABLED = True


def set_enabled(enabled: bool) -> None:
    global _ENABLED
    _ENABLED = enabled


def clear_log() -> None:
    _LOGS.clear()


_MAX_LOG_LINES = 300


def get_log() -> list[str]:
    if len(_LOGS) <= _MAX_LOG_LINES:
        return list(_LOGS)
    omitted = len(_LOGS) - _MAX_LOG_LINES
    return [f'[YTDLP-iOS][debug] ... {omitted} earlier log lines omitted ...', *_LOGS[-_MAX_LOG_LINES:]]


def log(category: str, message: str) -> None:
    if not _ENABLED:
        return
    line = f'[YTDLP-iOS][{category}] {message}'
    _LOGS.append(line)
    try:
        sys.stderr.write(line + '\n')
        sys.stderr.flush()
    except Exception:  # noqa: BLE001
        pass


def log_preview(category: str, label: str, text: str, limit: int = 240) -> None:
    if not text:
        log(category, f'{label}: <empty>')
        return
    preview = text.replace('\n', '\\n')
    if len(preview) > limit:
        preview = preview[:limit] + '...'
    log(category, f'{label} len={len(text)} preview={preview}')


class log_timing:
    def __init__(self, category: str, action: str):
        self.category = category
        self.action = action
        self._start = 0.0

    def __enter__(self):
        self._start = time.monotonic()
        log(self.category, f'{self.action} start')
        return self

    def __exit__(self, exc_type, exc, tb):
        elapsed_ms = int((time.monotonic() - self._start) * 1000)
        if exc_type is None:
            log(self.category, f'{self.action} done ({elapsed_ms}ms)')
        else:
            log(self.category, f'{self.action} failed ({elapsed_ms}ms): {exc}')
