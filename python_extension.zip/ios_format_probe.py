"""并发探测媒体格式 URL，剔除明确不可达（403/404/410/451）的链接。

HLS：拉 manifest 后只抽检 **一个** 媒体分片（不必校验全部）。
含 googlevideo / videoplayback；不再因「Range 误报」整站跳过。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

_BLOCKED_STATUS = frozenset({403, 404, 410, 451})
_DEFAULT_MAX_WORKERS = 8
_PROBE_TIMEOUT = 12
_PROBE_READ_BYTES = 8192
_SEGMENT_READ_BYTES = 512
_M3U8_PROTOCOLS = frozenset({'m3u8', 'm3u8_native', 'm3u8_frag'})


def _log(message: str) -> None:
    try:
        from ios_debug_log import log

        log('format_probe', message)
    except Exception:  # noqa: BLE001
        pass


def is_storyboard_format(fmt):
    """YouTube storyboard（MHTML 缩略图条），非可下载音视频。"""
    protocol = (fmt.get('protocol') or '').lower()
    if protocol == 'mhtml':
        return True
    note = (fmt.get('format_note') or '').lower()
    if 'storyboard' in note:
        return True
    format_id = (fmt.get('format_id') or '').lower()
    return format_id.startswith('sb')


def strip_storyboard_formats(formats):
    """从展示/下载列表中移除 storyboard 格式。"""
    return [fmt for fmt in (formats or []) if not is_storyboard_format(fmt)]


def _url_preview(url: str, limit: int = 96) -> str:
    text = str(url or '')
    return text if len(text) <= limit else text[:limit] + '...'


def _should_skip_probe(fmt):
    """仅跳过无 http(s) URL / storyboard；googlevideo 等 CDN 一律探测。"""
    if is_storyboard_format(fmt):
        return True
    url = (fmt.get('url') or '').lower()
    return not url.startswith(('http://', 'https://'))


def _looks_like_m3u8(url: str, protocol: str = '') -> bool:
    proto = (protocol or '').lower()
    if proto in _M3U8_PROTOCOLS:
        return True
    lower = (url or '').lower()
    return '.m3u8' in lower or 'playlist/index.m3u8' in lower or '/manifest.' in lower


def _probe_http(url, headers, *, range_header=None, read_bytes=0):
    """发起轻量 GET。

    返回 (ok, status_or_reason)。网络超时等模糊错误 → 保留格式 (True, 'soft_error')。
    对签名 CDN 默认不用 Range（Range 易单独 403，与整文件 GET 不一致）。
    """
    merged = {str(k): str(v) for k, v in (headers or {}).items() if v is not None}
    if range_header:
        merged['Range'] = range_header
    request = Request(url, headers=merged, method='GET')
    try:
        with urlopen(request, timeout=_PROBE_TIMEOUT) as response:
            code = getattr(response, 'status', None) or response.getcode()
            if code in _BLOCKED_STATUS:
                return False, code
            if read_bytes > 0:
                chunk = response.read(read_bytes)
                if not chunk:
                    return False, f'empty_body:{code}'
            return True, code
    except HTTPError as exc:
        if exc.code in _BLOCKED_STATUS:
            return False, exc.code
        return True, f'http:{exc.code}'
    except (URLError, TimeoutError, OSError, ValueError) as exc:
        return True, f'soft:{type(exc).__name__}'


def _iter_m3u8_uris(manifest_text):
    """产出 manifest 中非标签 URI 行（相对或绝对）。"""
    for line in manifest_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        yield stripped


def _first_media_segment_url(manifest_text, base_url):
    for uri in _iter_m3u8_uris(manifest_text):
        if uri.startswith(('http://', 'https://')):
            return uri
        return urljoin(base_url, uri)
    return None


def _first_variant_playlist_url(manifest_text, base_url):
    """Master playlist：取第一条 #EXT-X-STREAM-INF 后的子 playlist。"""
    lines = manifest_text.splitlines()
    for index, line in enumerate(lines):
        if not line.strip().startswith('#EXT-X-STREAM-INF'):
            continue
        for follow in lines[index + 1 :]:
            stripped = follow.strip()
            if not stripped or stripped.startswith('#'):
                continue
            if stripped.startswith(('http://', 'https://')):
                return stripped
            return urljoin(base_url, stripped)
    return None


def _fetch_m3u8_text(url, headers):
    """拉取 m3u8 文本。失败返回 (None, status_reason)。"""
    merged = {str(k): str(v) for k, v in (headers or {}).items() if v is not None}
    request = Request(url, headers=merged, method='GET')
    try:
        with urlopen(request, timeout=_PROBE_TIMEOUT) as response:
            code = getattr(response, 'status', None) or response.getcode()
            if code in _BLOCKED_STATUS:
                return None, code
            data = response.read(_PROBE_READ_BYTES)
    except HTTPError as exc:
        if exc.code in _BLOCKED_STATUS:
            return None, exc.code
        return None, f'http:{exc.code}'
    except (URLError, TimeoutError, OSError, ValueError) as exc:
        return None, f'soft:{type(exc).__name__}'

    if not data or b'#EXTM3U' not in data:
        return None, 'invalid_m3u8'
    return data.decode('utf-8', errors='replace'), 'ok'


def _probe_one_segment(segment_url, headers):
    """只探测一个分片：不用 Range，读少量字节（贴近真实下载起始）。"""
    ok, reason = _probe_http(
        segment_url,
        headers,
        read_bytes=_SEGMENT_READ_BYTES,
    )
    if not ok:
        _log(
            f'hls segment blocked reason={reason} '
            f'seg={_url_preview(segment_url)}'
        )
    return ok, reason


def _probe_m3u8(url, headers):
    """探测 m3u8：manifest 可达后，对 media playlist 抽检一个分片。

    Master playlist 会跟进第一条 variant，再抽检一个分片。
    """
    text, reason = _fetch_m3u8_text(url, headers)
    if text is None:
        if isinstance(reason, int) and reason in _BLOCKED_STATUS:
            _log(f'hls manifest blocked status={reason} url={_url_preview(url)}')
            return False
        if reason == 'invalid_m3u8':
            _log(f'hls manifest invalid url={_url_preview(url)}')
            return False
        # soft / 其它 HTTP：保留
        _log(f'hls manifest soft-keep reason={reason} url={_url_preview(url)}')
        return True

    media_text = text
    media_base = url

    if '#EXT-X-STREAM-INF' in text:
        variant = _first_variant_playlist_url(text, url)
        if not variant:
            _log(f'hls master has no variant url={_url_preview(url)}')
            return True
        media_text, media_reason = _fetch_m3u8_text(variant, headers)
        if media_text is None:
            if isinstance(media_reason, int) and media_reason in _BLOCKED_STATUS:
                _log(
                    f'hls variant blocked status={media_reason} '
                    f'url={_url_preview(variant)}'
                )
                return False
            if media_reason == 'invalid_m3u8':
                _log(f'hls variant invalid url={_url_preview(variant)}')
                return False
            _log(
                f'hls variant soft-keep reason={media_reason} '
                f'url={_url_preview(variant)}'
            )
            return True
        media_base = variant

    segment_url = _first_media_segment_url(media_text, media_base)
    if not segment_url:
        _log(f'hls media has no segment url={_url_preview(media_base)}')
        return True

    ok, _seg_reason = _probe_one_segment(segment_url, headers)
    return ok


def probe_format(fmt):
    if _should_skip_probe(fmt):
        return True

    url = fmt.get('url') or ''
    protocol = (fmt.get('protocol') or '').lower()
    headers = fmt.get('http_headers') or {}
    format_id = fmt.get('format_id') or '?'

    if _looks_like_m3u8(url, protocol):
        ok = _probe_m3u8(url, headers)
        if not ok:
            _log(
                f'remove format_id={format_id} kind=hls '
                f'url={_url_preview(url)}'
            )
        return ok

    if protocol in ('http_dash_segments', 'dash'):
        ok, reason = _probe_http(url, headers, read_bytes=_PROBE_READ_BYTES)
    else:
        # progressive：不用 Range，避免 googlevideo 单独拒绝 Range
        ok, reason = _probe_http(url, headers, read_bytes=_SEGMENT_READ_BYTES)

    if not ok:
        _log(
            f'remove format_id={format_id} kind=progressive '
            f'reason={reason} url={_url_preview(url)}'
        )
    return ok


def _probe_unique_urls(url_to_fmt, max_workers):
    if not url_to_fmt:
        return set()

    bad_urls = set()
    workers = min(max_workers, len(url_to_fmt))

    def run_probe(item):
        probe_url, fmt = item
        return probe_url, probe_format(fmt)

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(run_probe, item) for item in url_to_fmt.items()]
        for future in as_completed(futures):
            try:
                probe_url, ok = future.result()
                if not ok:
                    bad_urls.add(probe_url)
            except Exception as exc:  # noqa: BLE001
                _log(f'probe exception keep url err={exc}')
                continue
    return bad_urls


def filter_unreachable_formats(formats, max_workers=_DEFAULT_MAX_WORKERS):
    """按 URL 去重后并发探测，返回 (过滤后列表, 剔除数量)。"""
    if not formats:
        return formats, 0

    url_to_fmt = {}
    skipped = 0
    for fmt in formats:
        if _should_skip_probe(fmt):
            skipped += 1
            continue
        url = fmt.get('url')
        if not url or not url.startswith(('http://', 'https://')):
            continue
        url_to_fmt.setdefault(url, fmt)

    _log(
        f'begin formats={len(formats)} unique_probe_urls={len(url_to_fmt)} '
        f'skipped_non_probe={skipped}'
    )
    bad_urls = _probe_unique_urls(url_to_fmt, max_workers)
    stripped = strip_storyboard_formats(
        [fmt for fmt in formats if fmt.get('url') not in bad_urls]
    )
    removed = len(formats) - len(stripped)
    _log(
        f'done kept={len(stripped)} removed={removed} '
        f'bad_urls={len(bad_urls)}'
    )
    return stripped, removed


def filter_unreachable_urls(urls, headers=None, max_workers=_DEFAULT_MAX_WORKERS):
    """过滤推荐直链列表，headers 为 info 级默认请求头。"""
    unique_urls = []
    seen = set()
    for url in urls or []:
        if not url or url in seen:
            continue
        seen.add(url)
        unique_urls.append(url)

    if not unique_urls:
        return []

    url_to_fmt = {}
    for url in unique_urls:
        if not url.startswith(('http://', 'https://')):
            continue
        protocol = 'm3u8' if _looks_like_m3u8(url) else 'https'
        fmt = {'url': url, 'protocol': protocol, 'http_headers': headers or {}}
        if _should_skip_probe(fmt):
            continue
        url_to_fmt[url] = fmt

    _log(f'filter_urls begin count={len(url_to_fmt)}')
    bad_urls = _probe_unique_urls(url_to_fmt, max_workers)
    kept = [url for url in unique_urls if url not in bad_urls]
    _log(f'filter_urls done kept={len(kept)} removed={len(bad_urls)}')
    return kept
