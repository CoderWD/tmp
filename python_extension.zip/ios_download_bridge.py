"""Swift ↔ Python 后台 HTTP 下载桥接。"""

from __future__ import annotations

import errno
import json
import threading

from ios_debug_log import log, log_preview

_RUNNER = None
_ACTIVE_TASK_ID = threading.local()


def register_runner(runner) -> None:
    global _RUNNER
    if runner is None or not callable(runner):
        raise TypeError('runner must be callable')
    _RUNNER = runner
    log('download_bridge', 'Swift background download runner registered')


def unregister_runner() -> None:
    global _RUNNER
    _RUNNER = None
    log('download_bridge', 'Swift background download runner unregistered')


def is_bridge_available() -> bool:
    return _RUNNER is not None


def set_active_task_id(task_id: str) -> None:
    _ACTIVE_TASK_ID.value = str(task_id or '')


def get_active_task_id() -> str:
    return str(getattr(_ACTIVE_TASK_ID, 'value', '') or '')


def clear_active_task_id() -> None:
    if hasattr(_ACTIVE_TASK_ID, 'value'):
        delattr(_ACTIVE_TASK_ID, 'value')


def download_via_bridge(spec: dict) -> dict:
    if _RUNNER is None:
        raise OSError(
            errno.ENOENT,
            'Swift download runner not registered. '
            'Call PythonDownloadBridge.registerRunnerIfNeeded() before download.',
        )
    if not isinstance(spec, dict):
        raise TypeError('spec must be a dict')

    transfer_id = str(spec.get('transfer_id') or '')
    log(
        'download_bridge',
        f'download transfer_id={transfer_id} url={spec.get("url", "")!r} '
        f'dest={spec.get("destination_path", "")!r}',
    )
    log_preview('download_bridge', 'headers', str(spec.get('headers') or {}), limit=200)

    raw = _RUNNER(spec)
    if isinstance(raw, str):
        result = json.loads(raw)
    elif isinstance(raw, dict):
        result = raw
    else:
        raise RuntimeError('Download runner must return dict or JSON string')

    log(
        'download_bridge',
        f'done transfer_id={transfer_id} ok={result.get("ok")} '
        f'bytes={result.get("downloaded_bytes")}',
    )
    return result
