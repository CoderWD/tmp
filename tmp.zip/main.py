from yt_dlp import YoutubeDL
import os
import sys
import json


def make_cache_dir(library_path):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if not library_path:
        cache_dir = os.path.join(current_dir, ".cache")
    else:
        cache_dir = os.path.join(library_path, ".cache")

    # 判断目录是否存在
    if not os.path.exists(cache_dir):
        # 如果目录不存在，创建目录
        os.makedirs(cache_dir)
        # 设置权限为可读写（仅当前用户）
        os.chmod(cache_dir, 0o700)
        print(f"cache dir '{cache_dir}' created.")
    else:
        print(f"cache dir '{cache_dir}' already exists.")

    return cache_dir


def create_cookie_file(cookie_str, cache_dir):
    """
    创建临时的Netscape格式cookie文件
    :param cookie_str: Netscape格式的cookie字符串
    :param cache_dir: 缓存目录路径
    :return: cookie文件路径，如果cookie为空则返回None
    """
    # 检查输入是否为空
    if not cookie_str.strip():
        return None
    
    # 创建临时cookie文件路径
    cookie_file_path = os.path.join(cache_dir, "cookies.txt")
    
    try:
        # 确保cookie字符串是正确的Netscape格式
        lines = cookie_str.strip().splitlines()
        
        # 如果第一行不是Netscape标识符，添加它
        if not lines or not lines[0].startswith("# Netscape HTTP Cookie File"):
            cookie_content = "# Netscape HTTP Cookie File\n" + cookie_str
        else:
            cookie_content = cookie_str
        
        # 写入cookie文件
        with open(cookie_file_path, 'w', encoding='utf-8') as f:
            f.write(cookie_content)
        
        print(f"Cookie file created: {cookie_file_path}")
        return cookie_file_path
        
    except Exception as e:
        print(f"Failed to create cookie file: {e}")
        return None


def do_extract(url, ydl_opts):
    with YoutubeDL(ydl_opts) as ydl:
        try:
            info_dict = ydl.extract_info(url, download=False)  # 提取信息而不下载
            for format_info in info_dict.get('formats', []):
                print(format_info.get('url'))
            # 输出所有格式的下载链接
            return json.dumps(info_dict, indent=4)

        except Exception as e:
            # 异常处理代码
            print(f"An error occurred: {e}")
            error_dic = {
                "url": url,
                "errMsg": str(e)
            }
            return json.dumps(error_dic, indent=4)

def extract(url, cookie_str, json_param_str, library_path):
    print(f"extract from python: {url}")
    print(f"param: {json_param_str}")
    print(f"cookie: {cookie_str}")
    result = ""
    cookie_file_path = None
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 遍历当前目录及其所有子目录
        for root, dirs, files in os.walk(current_dir):
            if root not in sys.path:  # 避免重复添加
                sys.path.append(root)

        cache_dir = make_cache_dir(library_path)
        # 15秒超时时间
        socket_timeout = 15
        
        # 配置下载选项，只解析不下载
        ydl_opts = {
            'socket_timeout': socket_timeout,
            'quiet': True,  # 禁用其他输出
            'dumpjson': True,  # 输出解析后的 JSON 数据
            'cachedir': cache_dir,  # 设置缓存目录为当前脚本所在目录
            'noplaylist': True,  # 仅处理单个视频，不处理播放列表
        }
        result = do_extract(url, ydl_opts)
        print(f"step 1 result: {result}")
        # 判断result字符串中是否包含Sign in to confirm you’re not a bot或--cookies
        if "Sign in to confirm you’re not a bot" in result or "--cookies" in result:
            cookie_file_path = create_cookie_file(cookie_str, cache_dir)
            if cookie_file_path:
                ydl_opts['cookiefile'] = cookie_file_path
                result = do_extract(url, ydl_opts)
                print(f"step 2 result: {result}")
                return result
            else:
                print("Failed to create cookie file.")
                return result
        else:
            print("No need to use cookies.")
            return result

    except Exception as e:
        error_dic = {
            "url": url,
            "errMsg": str(e)
        }
        result = json.dumps(error_dic, indent=4)
        print(f"Error: {e}")

    finally:
        # 清理临时cookie文件
        if cookie_file_path and os.path.exists(cookie_file_path):
            try:
                os.remove(cookie_file_path)
                print(f"Cleaned up cookie file: {cookie_file_path}")
            except Exception as cleanup_error:
                print(f"Failed to cleanup cookie file: {cleanup_error}")

    return result


# if __name__ == '__main__':
#     url = "https://www.youtube.com/watch?v=T4SimnaiktU"
#     cookie_str = ""
#     extract(url, cookie_str,"", None)
