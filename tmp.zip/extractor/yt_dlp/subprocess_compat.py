import threading
import queue
import time
import os
import re
import sys
from io import StringIO


class subprocess:
    PIPE = -1
    STDOUT = -2
    DEVNULL = -3

    def __init__(self):
        None

    @staticmethod
    def call(args, **kwargs):
        """
        用线程模拟 subprocess.call() 的行为。
        :param args: 命令参数列表或目标函数
        :param kwargs: 关键字参数
        :return: 线程任务的返回码 (0 表示成功，非 0 表示失败)
        """
        if callable(args):
            # 如果传入的是函数，直接执行
            target = args
            target_args = kwargs.get('args', ())
            target_kwargs = kwargs.get('kwargs', {})
        else:
            # 如果是命令列表，模拟命令执行
            target = lambda: print(f"模拟执行命令: {' '.join(args) if isinstance(args, list) else args}")
            target_args = ()
            target_kwargs = {}
        
        result_queue = queue.Queue()

        def thread_task():
            try:
                result = target(*target_args, **target_kwargs)
                result_queue.put((0, result))  # 0 表示成功
            except Exception as e:
                result_queue.put((1, str(e)))  # 非 0 表示失败，保存错误信息

        # 创建线程并启动
        task_thread = threading.Thread(target=thread_task)
        task_thread.start()
        task_thread.join()  # 等待线程完成

        # 获取结果并返回退出码
        returncode, _ = result_queue.get()
        return returncode

    @staticmethod
    def check_call(args, **kwargs):
        """
        模拟 subprocess.check_call()，如果返回码非零则抛出异常
        """
        returncode = subprocess.call(args, **kwargs)
        if returncode != 0:
            raise RuntimeError(f"Command failed with return code {returncode}")
        return returncode

    @staticmethod
    def check_output(args, **kwargs):
        """
        模拟 subprocess.check_output()，返回输出内容
        """
        popen = subprocess.Popen(args, stdout=subprocess.PIPE, **kwargs)
        stdout, stderr = popen.communicate()
        if popen.returncode != 0:
            raise RuntimeError(f"Command failed with return code {popen.returncode}")
        return stdout

    @staticmethod
    def run(args, **kwargs):
        """
        模拟 subprocess.run()，返回 CompletedProcess 对象
        """
        popen = subprocess.Popen(args, **kwargs)
        stdout, stderr = popen.communicate()
        return CompletedProcess(args, popen.returncode, stdout, stderr)

    class Popen:
        def __init__(self, args, bufsize=-1, executable=None, stdin=None, stdout=None, 
                     stderr=None, preexec_fn=None, close_fds=True, shell=False, 
                     cwd=None, env=None, universal_newlines=None, startupinfo=None, 
                     creationflags=0, restore_signals=True, start_new_session=False, 
                     pass_fds=(), encoding=None, errors=None, text=None, **kwargs):
            """
            模拟 subprocess.Popen 类，用线程代替进程运行任务。
            """
            # 处理参数
            if callable(args):
                self.target = args
                self.args = kwargs.get('args', ())
                self.kwargs = kwargs.get('kwargs', {})
            else:
                # 模拟命令执行
                self.target = self._simulate_command
                self.args = (args,)
                self.kwargs = {}
            
            # 设置输出流
            self.stdin = stdin
            self.stdout = self._setup_output_stream(stdout)
            self.stderr = self._setup_output_stream(stderr)
            self.returncode = None
            
            # 线程控制
            self._thread = None
            self._stop_event = threading.Event()
            self._started = False
            self._closed = False
            
            # 自动启动（模拟真实 Popen 行为）
            self.start()

        def __enter__(self):
            """上下文管理器入口"""
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            """上下文管理器出口，确保资源清理"""
            try:
                if self._thread and self._thread.is_alive():
                    self.terminate()
                    # 等待线程结束
                    self._thread.join(timeout=1)
            except:
                pass
            finally:
                self._closed = True
            return False

        def _setup_output_stream(self, stream):
            """设置输出流"""
            if stream == subprocess.PIPE:
                return queue.Queue()
            elif stream == subprocess.DEVNULL:
                return None
            elif stream == subprocess.STDOUT:
                return self.stdout
            else:
                return stream

        def _simulate_command(self, cmd_args):
            """模拟命令执行"""
            if isinstance(cmd_args, list):
                result = f"模拟执行命令: {' '.join(str(arg) for arg in cmd_args)}"
            else:
                result = f"模拟执行命令: {cmd_args}"
            return result

        def _run(self):
            """
            在线程中运行目标函数，并捕获输出和返回码。
            """
            try:
                # 执行目标函数
                result = self.target(*self.args, **self.kwargs)
                
                # 检查是否被终止
                if self._stop_event.is_set():
                    self.returncode = -1
                    return
                
                # 处理输出
                if self.stdout and hasattr(self.stdout, 'put'):
                    self.stdout.put(str(result) if result is not None else "")
                
                self.returncode = 0  # 任务成功
                
            except Exception as e:
                # 处理错误
                if self.stderr and hasattr(self.stderr, 'put'):
                    self.stderr.put(str(e))
                elif self.stdout and hasattr(self.stdout, 'put'):
                    self.stdout.put(f"Error: {str(e)}")
                
                self.returncode = 1  # 任务失败

        def start(self):
            """启动线程"""
            if not self._started and not self._closed:
                self._thread = threading.Thread(target=self._run)
                self._thread.daemon = True
                self._thread.start()
                self._started = True

        def wait(self, timeout=None):
            """
            等待线程完成，模拟 subprocess 的 wait 方法。
            :param timeout: 等待超时时间
            """
            if self._thread:
                self._thread.join(timeout)
                if self._thread.is_alive():
                    raise TimeoutError("Thread did not finish within the timeout period.")
            return self.returncode

        def terminate(self):
            """终止线程运行，模拟 subprocess 的 terminate 方法。"""
            self._stop_event.set()
            if self._thread and self._thread.is_alive():
                self._thread.join(timeout=1)  # 等待最多1秒
                if self._thread.is_alive():
                    # 强制终止（在真实环境中这里可能需要更强的措施）
                    self.returncode = -1

        def kill(self):
            """强制终止，模拟 subprocess 的 kill 方法"""
            self.terminate()

        def communicate(self, input=None, timeout=None):
            """
            等待线程完成，并返回 stdout 和 stderr 的内容。
            :param input: 输入数据（此实现中忽略）
            :param timeout: 等待超时时间
            """
            try:
                self.wait(timeout)
            except TimeoutError:
                self.terminate()
                raise TimeoutError("Thread was terminated due to timeout.")

            # 收集输出
            stdout_content = []
            stderr_content = []
            
            if self.stdout and hasattr(self.stdout, 'empty'):
                while not self.stdout.empty():
                    try:
                        stdout_content.append(self.stdout.get_nowait())
                    except queue.Empty:
                        break
                        
            if self.stderr and hasattr(self.stderr, 'empty'):
                while not self.stderr.empty():
                    try:
                        stderr_content.append(self.stderr.get_nowait())
                    except queue.Empty:
                        break
            
            stdout_result = "\n".join(stdout_content) if stdout_content else ""
            stderr_result = "\n".join(stderr_content) if stderr_content else ""
            
            return stdout_result, stderr_result

        def poll(self):
            """
            检查线程是否完成，模拟 subprocess 的 poll。
            :return: None 表示任务未完成，或者返回 returncode
            """
            if self._thread and self._thread.is_alive():
                return None
            return self.returncode

        def send_signal(self, signal):
            """模拟发送信号，实际上调用 terminate"""
            self.terminate()

        @property
        def pid(self):
            """模拟进程ID，返回线程ID"""
            if self._thread:
                return self._thread.ident
            return None


class CompletedProcess:
    """模拟 subprocess.CompletedProcess"""
    def __init__(self, args, returncode, stdout=None, stderr=None):
        self.args = args
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    def check_returncode(self):
        """如果返回码非零则抛出异常"""
        if self.returncode != 0:
            raise RuntimeError(f"Command failed with return code {self.returncode}")


# 异常类
class CalledProcessError(Exception):
    """模拟 subprocess.CalledProcessError"""
    def __init__(self, returncode, cmd, output=None, stderr=None):
        self.returncode = returncode
        self.cmd = cmd
        self.output = output
        self.stderr = stderr
        super().__init__(f"Command '{cmd}' returned non-zero exit status {returncode}")


class TimeoutExpired(Exception):
    """模拟 subprocess.TimeoutExpired"""
    def __init__(self, cmd, timeout, output=None, stderr=None):
        self.cmd = cmd
        self.timeout = timeout
        self.output = output
        self.stderr = stderr
        super().__init__(f"Command '{cmd}' timed out after {timeout} seconds")


# 定义要检查的模块和替换格式
MODULE_TO_CHECK = "import subprocess"


# 获取相对于基准文件的相对路径导入语句
def generate_relative_import(base_dir, target_dir):
    base_parts = base_dir.split(os.sep)
    target_parts = target_dir.split(os.sep)

    # 找到公共路径前缀的长度
    common_length = 0
    for base_part, target_part in zip(base_parts, target_parts):
        if base_part == target_part:
            common_length += 1
        else:
            break

    # 计算相对层级并构造相对导入路径
    upward_levels = len(target_parts) - common_length
    relative_import = "." * (upward_levels + 1)  # +1 是为了覆盖同级情况也正确
    return f"from {relative_import}subprocess_compat import subprocess"


# 递归检查和修改 .py 文件
def process_directory(base_dir):
    for root, _, files in os.walk(base_dir):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                update_imports(base_dir, file_path)


# 更新文件中的导入语句
def update_imports(base_dir, file_path):
    try:
        new_import = generate_relative_import(base_dir, os.path.dirname(file_path))

        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        updated_lines = []
        modified = False

        for line in lines:
            # 精确匹配只有 MODULE_TO_CHECK 的行
            if line.strip() == MODULE_TO_CHECK:
                updated_lines.append(f"{new_import}\n")
                modified = True
            else:
                updated_lines.append(line)

        if modified:
            with open(file_path, "w", encoding="utf-8") as f:
                f.writelines(updated_lines)
            print(f"Updated imports in: {file_path}")
    except Exception as e:
        print(f"Error processing {file_path}: {e}")


# 主函数
def hook_subprocess():
    """Hook subprocess imports in all Python files"""
    # 获取当前文件的目录
    current_file = os.path.abspath(__file__)
    base_dir = os.path.dirname(current_file)

    # 递归处理目录
    process_directory(base_dir)
    print("Subprocess hooking completed!")


if __name__ == '__main__':
    hook_subprocess() 