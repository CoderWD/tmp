"""iOS 下载进度桥接：供 Python progress_hook 向 Swift 回传状态。"""

from __future__ import annotations

import json
import threading

_lock = threading.Lock()
_progress: dict[str, dict] = {}
_handler = None
_cancelled: set[str] = set()


def register_handler(handler) -> None:
    global _handler
    _handler = handler


def request_cancel(task_id: str) -> None:
    with _lock:
        _cancelled.add(str(task_id))


def is_cancelled(task_id: str) -> bool:
    with _lock:
        return str(task_id) in _cancelled


def clear_task(task_id: str) -> None:
    with _lock:
        _progress.pop(str(task_id), None)
        _cancelled.discard(str(task_id))


def report_progress(task_id: str, payload) -> None:
    task_id = str(task_id)
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except json.JSONDecodeError:
            return
    if not isinstance(payload, dict):
        return
    with _lock:
        merged = dict(_progress.get(task_id, {}))
        merged.update(payload)
        _progress[task_id] = merged

    if _handler is not None:
        try:
            _handler(task_id, json.dumps(merged, ensure_ascii=False))
        except Exception:  # noqa: BLE001
            pass


def get_progress(task_id: str) -> str:
    with _lock:
        data = _progress.get(str(task_id))
    return json.dumps(data or {}, ensure_ascii=False)
