"""Swift ↔ Python JS 执行桥接。

Swift 通过 `register_runner` 注入基于 JavaScriptCore 的执行器；
yt-dlp EJS / subprocess hook 经此模块执行 JavaScript。
"""

from __future__ import annotations

from ios_debug_log import log, log_preview

_RUNNER = None


def register_runner(runner) -> None:
    """注册 JS 执行器：runner(source: str) -> (stdout, stderr) | str。"""
    global _RUNNER
    if runner is None or not callable(runner):
        raise TypeError('runner must be callable')
    _RUNNER = runner
    log('js_bridge', 'Swift JS runner registered')


def unregister_runner() -> None:
    global _RUNNER
    _RUNNER = None
    log('js_bridge', 'Swift JS runner unregistered')


def is_bridge_available() -> bool:
    return _RUNNER is not None


def evaluate_via_bridge(source: str) -> tuple[str, str]:
    log('js_bridge', f'evaluate_via_bridge called bridge_available={is_bridge_available()}')
    if _RUNNER is None:
        raise RuntimeError(
            'Swift JS runner not registered. '
            'Call PythonJSBridge.registerRunnerIfNeeded() before extract.'
        )
    if not source or not str(source).strip():
        raise RuntimeError('empty JavaScript source')

    log_preview('js_bridge', 'JS source', source)
    try:
        result = _RUNNER(source)
    except Exception as exc:  # noqa: BLE001
        log('js_bridge', f'Swift runner raised: {exc}')
        raise

    if isinstance(result, (list, tuple)):
        stdout = result[0] if len(result) > 0 else ''
        stderr = result[1] if len(result) > 1 else ''
        stdout_s = str(stdout or '')
        stderr_s = str(stderr or '')
        log_preview('js_bridge', 'JS stdout', stdout_s)
        if stderr_s:
            log_preview('js_bridge', 'JS stderr', stderr_s)
        if not stdout_s:
            log('js_bridge', 'WARNING: Swift runner returned empty stdout (EJS may have failed)')
        log('js_bridge', f'evaluate_via_bridge return stdout_len={len(stdout_s)} stderr_len={len(stderr_s)}')
        return stdout_s, stderr_s
    result_s = str(result)
    log_preview('js_bridge', 'JS result', result_s)
    if not result_s:
        log('js_bridge', 'WARNING: Swift runner returned empty str (EJS may have failed)')
    log('js_bridge', f'evaluate_via_bridge return stdout_len={len(result_s)}')
    return result_s, ''
