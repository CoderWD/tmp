"""将 subprocess 调用替换为线程内执行，适配 iOS 禁止多进程的限制。

iOS 无法 fork/exec 外部二进制；本模块在导入 yt_dlp 之前安装 hook：
- 用线程模拟 subprocess.Popen 的 communicate / wait / poll
- 对 JS 运行时（node/deno/quickjs/bun）走 `ios_js_bridge`（Swift JavaScriptCore）
- 其余外部命令返回 ENOENT，由 yt-dlp 按「工具不可用」处理
"""

from __future__ import annotations

import errno
import os
import shlex
import subprocess
import sys
import threading
from typing import Any

from ios_ffmpeg_evaluator import is_ffmpeg_program
from ios_js_evaluator import (
    _normalize_program_name,
    clean_js_runtime_stderr,
    evaluate_javascript,
    evaluate_script_file,
    fake_version_output,
    is_ios_platform,
    is_js_runtime_name,
    is_js_stdin_execution,
    is_quickjs_script_execution,
    is_version_probe,
)
from ios_debug_log import log, log_preview

_HOOK_INSTALLED = False
_ORIGINAL_POPEN = subprocess.Popen


def _as_text(data: bytes | str | None, text_mode: bool) -> bytes | str:
    if data is None:
        return '' if text_mode else b''
    if text_mode and isinstance(data, bytes):
        return data.decode('utf-8', errors='replace')
    if not text_mode and isinstance(data, str):
        return data.encode('utf-8', errors='replace')
    return data


def _normalize_argv(args: Any, shell: bool) -> list[str]:
    if shell:
        if isinstance(args, (list, tuple)):
            command = ' '.join(str(part) for part in args)
        else:
            command = str(args)
        return [command]
    if isinstance(args, str):
        return shlex.split(args)
    return [str(part) for part in args]


def _basename(argv: list[str]) -> str:
    if not argv:
        return ''
    return _normalize_program_name(os.path.basename(argv[0]))


def _dispatch_command(
    argv: list[str],
    *,
    stdin_data: bytes | str | None,
    shell: bool,
    text_mode: bool,
) -> tuple[bytes | str, bytes | str, int]:
    if shell:
        raise OSError(
            errno.ENOTSUP,
            'iOS does not support shell subprocess execution',
        )

    if not argv:
        raise OSError(errno.ENOENT, 'empty command')

    program = _basename(argv)

    if is_js_runtime_name(program) and is_version_probe(argv):
        log('subprocess_hook', f'JS version probe argv={argv}')
        version = fake_version_output(program)
        if version is None:
            raise OSError(errno.ENOENT, f'unknown JS runtime probe: {program}')
        stdout = _as_text(version, text_mode)
        return stdout, _as_text('', text_mode), 0

    if is_js_stdin_execution(argv):
        log('subprocess_hook', f'JS stdin execution argv={argv}')
        if stdin_data is None:
            raise OSError(errno.EINVAL, 'JS runtime stdin execution requires input')
        source = stdin_data.decode('utf-8') if isinstance(stdin_data, bytes) else str(stdin_data)
        # Deno/Bun npm 探测脚本无法在 JavaScriptCore 执行，直接失败以促使上层换 provider
        if "import('npm:" in source or 'import("npm:' in source:
            log('subprocess_hook', 'rejecting Deno/Bun npm probe script for JSC')
            raise OSError(
                errno.ENOTSUP,
                'iOS JavaScriptCore cannot execute Deno npm import scripts',
            )
        stdout, stderr = evaluate_javascript(source)
        stderr = clean_js_runtime_stderr(stderr)
        return _as_text(stdout, text_mode), _as_text(stderr, text_mode), 0

    if is_quickjs_script_execution(argv):
        log('subprocess_hook', f'quickjs --script argv={argv}')
        script_path = argv[2]
        stdout, stderr = evaluate_script_file(script_path)
        stderr = clean_js_runtime_stderr(stderr)
        return _as_text(stdout, text_mode), _as_text(stderr, text_mode), 0

    if is_ffmpeg_program(program):
        try:
            from ios_ffmpeg_bridge import execute_via_bridge, is_bridge_available

            if is_bridge_available():
                log('subprocess_hook', f'ffmpeg bridge argv={argv}')
                stdout, stderr, returncode = execute_via_bridge(argv, stdin_data)
                return _as_text(stdout, text_mode), _as_text(stderr, text_mode), returncode
        except OSError:
            raise
        except Exception as exc:  # noqa: BLE001
            log('subprocess_hook', f'ffmpeg bridge failed: {exc}')
            stderr = _as_text(str(exc), text_mode)
            return _as_text('', text_mode), stderr, 1

    log('subprocess_hook', f'external command blocked argv={argv}')
    raise OSError(
        errno.ENOENT,
        f'iOS cannot execute external program: {argv[0]}',
    )


class ThreadPopen:
    """线程版 subprocess.Popen，API 兼容 yt-dlp 用法。"""

    def __init__(
        self,
        args,
        bufsize=-1,
        executable=None,
        stdin=None,
        stdout=None,
        stderr=None,
        preexec_fn=None,
        close_fds=True,
        shell=False,
        cwd=None,
        env=None,
        universal_newlines=None,
        startupinfo=None,
        creationflags=0,
        restore_signals=True,
        start_new_session=False,
        pass_fds=(),
        *,
        user=None,
        group=None,
        extra_groups=None,
        encoding=None,
        errors=None,
        text=None,
        umask=-1,
        pipesize=-1,
        process_group=None,
    ):
        del (
            bufsize, executable, preexec_fn, close_fds, startupinfo, creationflags,
            restore_signals, start_new_session, pass_fds, user, group, extra_groups,
            umask, pipesize, process_group,
        )

        self.args = args
        self.shell = shell
        self.cwd = cwd
        self.env = env
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr
        self.text = bool(text or universal_newlines or encoding or errors)
        self.encoding = encoding or ('utf-8' if self.text else None)
        self.errors = errors or 'replace'

        self.returncode: int | None = None
        self.pid = os.getpid()
        self._argv = _normalize_argv(args, shell)
        self._stdin_data: bytes | str | None = None
        self._stdout_data: bytes | str = _as_text(b'', self.text)
        self._stderr_data: bytes | str = _as_text(b'', self.text)
        self._wait_lock = threading.Lock()
        self._communication_started = False
        self._worker: threading.Thread | None = None
        self._killed = False
        self._worker_error: BaseException | None = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.wait()

    def _run_worker(self, input_data: bytes | str | None) -> None:
        try:
            stdout, stderr, returncode = _dispatch_command(
                self._argv,
                stdin_data=input_data,
                shell=self.shell,
                text_mode=self.text,
            )
            self._stdout_data = stdout
            self._stderr_data = stderr
            self.returncode = returncode
        except BaseException as exc:
            self._worker_error = exc
            if isinstance(exc, OSError):
                self.returncode = 127
            else:
                self.returncode = 1
        finally:
            self._worker = None

    def _start_worker(self, input_data: bytes | str | None) -> threading.Thread:
        worker = threading.Thread(
            target=self._run_worker,
            args=(input_data,),
            name='ios-subprocess-hook',
            daemon=True,
        )
        self._worker = worker
        worker.start()
        return worker

    def communicate(self, input=None, timeout=None):
        with self._wait_lock:
            if self._communication_started:
                raise ValueError('communicate() already called')
            self._communication_started = True

            if self._killed:
                return self._stdout_data, self._stderr_data

            worker = self._start_worker(input)
            worker.join(timeout)
            if worker.is_alive():
                self.kill()
                raise subprocess.TimeoutExpired(self.args, timeout)

            if self._worker_error is not None:
                raise self._worker_error

            return self._stdout_data, self._stderr_data

    def wait(self, timeout=None):
        with self._wait_lock:
            if self.returncode is not None:
                return self.returncode
            if self._worker is not None:
                self._worker.join(timeout)
                if self._worker.is_alive():
                    self.kill()
                    raise subprocess.TimeoutExpired(self.args, timeout)
            return self.returncode if self.returncode is not None else 0

    def poll(self):
        with self._wait_lock:
            if self._worker is not None and self._worker.is_alive():
                return None
            return self.returncode

    def kill(self, timeout=0):
        del timeout
        self._killed = True
        self.returncode = -9
        if self._worker is not None and self._worker.is_alive():
            # 无法强制终止同进程线程；标记 killed 后由 communicate 返回
            pass

    def terminate(self):
        self.kill()


def _make_run():
    def run(*popenargs, input=None, capture_output=False, timeout=None, check=False, **kwargs):
        if capture_output:
            kwargs['stdout'] = subprocess.PIPE
            kwargs['stderr'] = subprocess.PIPE
        with ThreadPopen(*popenargs, **kwargs) as process:
            try:
                stdout, stderr = process.communicate(input, timeout=timeout)
            except subprocess.TimeoutExpired as exc:
                process.kill()
                raise exc
            retcode = process.poll()
            if check and retcode:
                raise subprocess.CalledProcessError(retcode, process.args, output=stdout, stderr=stderr)
        return subprocess.CompletedProcess(process.args, retcode, stdout, stderr)

    return run


def _make_call():
    def call(*popenargs, timeout=None, **kwargs):
        with ThreadPopen(*popenargs, **kwargs) as process:
            return process.wait(timeout=timeout)

    return call


def _make_check_call():
    def check_call(*popenargs, **kwargs):
        retcode = _make_call()(*popenargs, **kwargs)
        if retcode:
            cmd = kwargs.get('args')
            if cmd is None:
                cmd = popenargs[0]
            raise subprocess.CalledProcessError(retcode, cmd)
        return 0

    return check_call


def _make_check_output():
    def check_output(*popenargs, timeout=None, **kwargs):
        kwargs['stdout'] = subprocess.PIPE
        return _make_run()(*popenargs, timeout=timeout, **kwargs).stdout

    return check_output


def should_enable_ios_subprocess_hook(force: bool | None = None) -> bool:
    if force is not None:
        return force
    return is_ios_platform()


def apply_ios_subprocess_hook(force: bool | None = None) -> bool:
    """安装 subprocess hook；返回是否已安装。"""
    global _HOOK_INSTALLED

    if _HOOK_INSTALLED:
        return True
    if not should_enable_ios_subprocess_hook(force):
        return False

    subprocess.Popen = ThreadPopen  # type: ignore[assignment,misc]
    subprocess.run = _make_run()
    subprocess.call = _make_call()
    subprocess.check_call = _make_check_call()
    subprocess.check_output = _make_check_output()

    from ios_debug_log import log

    log('subprocess_hook', 'apply_ios_subprocess_hook installed')
    _HOOK_INSTALLED = True
    return True


def is_hook_installed() -> bool:
    return _HOOK_INSTALLED
