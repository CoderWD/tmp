"""yt-dlp 媒体下载入口（供 iOS Python 运行时调用）。"""

import json
import os
import sys

# iOS AVPlayer 原生可播编码优先：H.264(avc1) 视频 + AAC(mp4a) 音频，容器 mp4/m4a。
# 命中时合并只需 stream-copy；逐级放宽，最后回退默认 bv*+ba/b（可能需重编码）。
COMPAT_FORMAT_SPEC = (
    "bv*[vcodec^=avc1][ext=mp4]+ba[acodec^=mp4a][ext=m4a]/"
    "bv*[vcodec^=avc1]+ba[acodec^=mp4a]/"
    "b[vcodec^=avc1][acodec^=mp4a][ext=mp4]/"
    "b[ext=mp4]/"
    "bv*+ba/b"
)


def _setup_paths():
    root = os.path.dirname(os.path.abspath(__file__))
    if root not in sys.path:
        sys.path.insert(0, root)


def _install_ios_hooks():
    _setup_paths()
    try:
        from ios_debug_log import log
        from ios_subprocess_hook import apply_ios_subprocess_hook

        log('download_media', 'installing ios_subprocess_hook')
        apply_ios_subprocess_hook(force=True)
    except Exception as exc:  # noqa: BLE001
        sys.stderr.write(f'[download_media] ios_subprocess_hook failed: {exc}\n')


def _install_ejs_hook():
    try:
        from ios_debug_log import log
        from ios_ejs_hook import apply_ejs_hook

        log('download_media', 'installing ios_ejs_hook')
        installed = apply_ejs_hook(force=True)
        log('download_media', f'ios_ejs_hook installed={installed}')
    except Exception as exc:  # noqa: BLE001
        sys.stderr.write(f'[download_media] ios_ejs_hook failed: {exc}\n')


def _response(ok, url, error=None, **fields):
    from ios_debug_log import get_log

    payload = {
        "ok": ok,
        "url": url,
        "error": error,
        "debug_log": get_log(),
    }
    payload.update(fields)
    return json.dumps(payload, ensure_ascii=False)


def _cache_dir():
    root = os.path.dirname(os.path.abspath(__file__))
    cache = os.path.join(root, ".cache")
    os.makedirs(cache, exist_ok=True)
    return cache


def _safe_number(value):
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _uploader_from_info(info):
    if not info:
        return None
    for key in ("uploader", "channel", "creator", "artist", "uploader_id"):
        value = info.get(key)
        if value and str(value).strip():
            return str(value).strip()
    return None


def _metadata_from_info(info):
    if not info:
        return {}
    return {
        "title": info.get("title"),
        "uploader": _uploader_from_info(info),
        "thumbnail": info.get("thumbnail"),
        "duration": _safe_number(info.get("duration")),
        "id": info.get("id"),
        "extractor": info.get("extractor"),
    }


def _progress_payload(status_dict):
    status = status_dict.get("status")
    payload = {"status": status}
    info_dict = status_dict.get("info_dict")
    if info_dict:
        payload.update(_metadata_from_info(info_dict))
    if status == "downloading":
        payload["downloaded_bytes"] = status_dict.get("downloaded_bytes")
        payload["total_bytes"] = status_dict.get("total_bytes")
        payload["total_bytes_estimate"] = status_dict.get("total_bytes_estimate")
        payload["speed"] = _safe_number(status_dict.get("speed"))
        payload["eta"] = _safe_number(status_dict.get("eta"))
        payload["filename"] = status_dict.get("filename")
        payload["tmpfilename"] = status_dict.get("tmpfilename")
    elif status == "finished":
        payload["filename"] = status_dict.get("filename")
    elif status == "error":
        payload["error"] = str(status_dict.get("error") or "download error")
    return payload


def download(url, cookie_str="", output_dir="", task_id=""):
    """下载媒体 URL，通过 progress_hook 推送进度，返回 JSON 字符串。"""
    from ios_debug_log import clear_log, log
    from ios_progress_bridge import is_cancelled, report_progress

    clear_log()
    task_id = str(task_id or "")
    log(
        'download_media',
        f'start url={url} output_dir={output_dir} task_id={task_id} '
        f'cookie_lines={len(str(cookie_str).splitlines())}',
    )

    if not url or not str(url).strip():
        return _response(False, url or "", error="URL is empty")
    if not output_dir or not str(output_dir).strip():
        return _response(False, url, error="output_dir is empty")
    if not task_id:
        return _response(False, url, error="task_id is empty")

    os.makedirs(output_dir, exist_ok=True)

    _install_ios_hooks()

    try:
        from ios_download_hook import apply_ios_download_hook

        apply_ios_download_hook(force=True)
    except Exception as exc:  # noqa: BLE001
        log('download_media', f'ios_download_hook failed: {exc}')

    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        log('download_media', f'import yt_dlp failed: {exc}')
        return _response(False, url, error=f"import yt_dlp failed: {exc}")

    _install_ejs_hook()

    cache_dir = _cache_dir()

    def progress_hook(status_dict):
        if is_cancelled(task_id):
            raise Exception("Download cancelled")
        # bv*+ba 等多轨下载时，单片完成也会触发 finished；整任务完成由 Swift handleCompletion 处理
        if status_dict.get("status") == "finished":
            return
        report_progress(task_id, _progress_payload(status_dict))

    try:
        from ios_ffmpeg_bridge import is_bridge_available
        ffmpeg_ready = is_bridge_available()
    except Exception:  # noqa: BLE001
        ffmpeg_ready = False

    if ffmpeg_ready:
        # 优先挑 iOS AVPlayer 原生可播的 H.264(avc1) + AAC(mp4a)/mp4，
        # 使合并阶段只需 stream-copy（几秒完成），避免重编码；无兼容轨时回退 bv*+ba/b。
        format_spec = COMPAT_FORMAT_SPEC
        log('download_media', 'ydl_opts format=compat-avc1-mp4a (ffmpeg bridge ready)')
    else:
        format_spec = (
            "best*[acodec!=none][vcodec!=none][ext=mp4]/"
            "best*[acodec!=none][vcodec!=none]/"
            "best[ext=mp4]/best"
        )
        log('download_media', 'ydl_opts format=merged-single-file (no ffmpeg)')

    ydl_opts = {
        "quiet": False,
        "no_warnings": False,
        "verbose": True,
        "noplaylist": True,
        "socket_timeout": 60,
        "cachedir": cache_dir,
        "progress_hooks": [progress_hook],
        "outtmpl": os.path.join(output_dir, "%(title).80s [%(id)s].%(ext)s"),
        "format": format_spec,
        "merge_output_format": "mp4",
        "js_runtimes": {"node": {}},
        "remote_components": ["ejs:github"],
        "retries": 3,
        "fragment_retries": 3,
        "hls_prefer_native": True,
    }
    if ffmpeg_ready:
        ydl_opts["postprocessors"] = []

    from ios_cookies import apply_cookies_to_ydl_opts, cleanup_cookiefile

    cookies_file_path = apply_cookies_to_ydl_opts(
        ydl_opts, cookie_str, cache_dir, url=url
    )
    if cookies_file_path:
        log('download_media', f'using cookiefile={cookies_file_path}')
    elif ydl_opts.get("http_headers", {}).get("Cookie"):
        log('download_media', 'using Cookie http_header fallback')
    else:
        log('download_media', 'no cookies')

    downloaded_path = None
    info = None

    from ios_download_bridge import clear_active_task_id, set_active_task_id

    set_active_task_id(task_id)
    try:
        report_progress(task_id, {"status": "preparing"})
        log('download_media', 'YoutubeDL.download begin')
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if info:
                report_progress(
                    task_id,
                    {"status": "downloading", **_metadata_from_info(info)},
                )
            if is_cancelled(task_id):
                raise Exception("Download cancelled")
            if info:
                ydl.process_info(info)
                downloaded_path = ydl.prepare_filename(info)
            else:
                info = ydl.extract_info(url, download=True)
                if info:
                    downloaded_path = ydl.prepare_filename(info)
        log('download_media', f'YoutubeDL.download done path={downloaded_path!r}')
    except Exception as exc:
        if is_cancelled(task_id):
            log('download_media', 'download cancelled')
            return _response(False, url, error="Download cancelled", task_id=task_id)
        log('download_media', f'download failed: {exc}')
        report_progress(task_id, {"status": "error", "error": str(exc)})
        return _response(False, url, error=str(exc), task_id=task_id)
    finally:
        clear_active_task_id()
        cleanup_cookiefile(cookies_file_path)

    if not info:
        return _response(False, url, error="No info returned", task_id=task_id)

    if downloaded_path and not os.path.isabs(downloaded_path):
        downloaded_path = os.path.abspath(downloaded_path)

    if not downloaded_path or not os.path.exists(downloaded_path):
        return _response(
            False,
            url,
            error="Downloaded file not found",
            task_id=task_id,
        )

    file_size = os.path.getsize(downloaded_path)
    report_progress(
        task_id,
        {
            "status": "finished",
            "filename": downloaded_path,
            "downloaded_bytes": file_size,
            "total_bytes": file_size,
            **_metadata_from_info(info),
        },
    )

    formats = info.get("formats") or []
    log(
        'download_media',
        f'success title={info.get("title")!r} file={downloaded_path} size={file_size}',
    )
    return _response(
        True,
        url,
        task_id=task_id,
        title=info.get("title"),
        id=info.get("id"),
        extractor=info.get("extractor"),
        uploader=_uploader_from_info(info),
        duration=info.get("duration"),
        thumbnail=info.get("thumbnail"),
        file_path=downloaded_path,
        file_size=file_size,
        format_count=len(formats),
    )
