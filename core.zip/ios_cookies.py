"""把宿主提供的 Cookie 文本适配为 yt-dlp 可消费的认证输入。

首选生成唯一的临时 Netscape cookiefile，以保留域/path 等匹配语义；若输入无法
规范化为文件内容，才尝试写入 ``ydl_opts['http_headers']``。文件系统写入失败会
原样抛出，并不会自动进入 header 回退。模块不记录 Cookie 内容，调用方也不得
把原文、完整私有 URL 或临时绝对路径写入日志。
"""

from __future__ import annotations

import os
import uuid
from typing import Optional
from urllib.parse import urlparse

# Netscape 文件固定表头；模块没有进程级可变状态，临时文件名用 PID 与 UUID 隔离。
NETSCAPE_HEADER = "# Netscape HTTP Cookie File"


def _looks_like_netscape_row(line: str) -> bool:
    """判断单行是否具备 Netscape cookie 数据行的最小列数。

    Args:
        line: 已读取的一行文本。

    Returns:
        非空、非 ``#`` 开头且至少包含七个 tab 字段时为 ``True``。

    Side Effects:
        无。以 ``#`` 开头的行一律视为注释，不特殊保留扩展前缀行。
    """
    if not line or line.startswith("#"):
        return False
    parts = line.split("\t")
    return len(parts) >= 7


def _cookie_header_pairs(raw: str) -> list[tuple[str, str]]:
    """解析分号分隔的 Cookie 请求头文本。

    Args:
        raw: 未带 Netscape 列结构的请求头文本。

    Returns:
        按出现顺序组成的 ``(name, value)`` 列表；空段、无等号段及空名称被忽略。

    Side Effects:
        无。此函数不校验域、path、expiry 或安全属性。
    """
    pairs: list[tuple[str, str]] = []
    for piece in raw.split(";"):
        piece = piece.strip()
        if not piece or "=" not in piece:
            continue
        name, value = piece.split("=", 1)
        name = name.strip()
        if not name:
            continue
        pairs.append((name, value.strip()))
    return pairs


def _domain_for_url(url: str | None) -> str:
    """从 URL 计算合成 Netscape 行所需的域字段。

    Args:
        url: 可选上下文 URL，只使用其 hostname。

    Returns:
        带前导点的 host；输入为空或无法解析 hostname 时返回空字符串。

    Side Effects:
        无网络请求，也不验证域是否真实存在。
    """
    if not url:
        return ""
    host = urlparse(url).hostname or ""
    if not host:
        return ""
    # Netscape：前导点表示包含子域。
    return host if host.startswith(".") else f".{host}"


def normalize_netscape_cookie_text(cookie_str: str | None, url: str | None = None) -> str | None:
    """将支持的 Cookie 输入规范为完整 Netscape 文件文本。

    Args:
        cookie_str: Netscape 表头文本、无表头 tab 数据行或请求头风格文本。
        url: 请求头风格输入所需的域上下文；本函数只解析 hostname，不联网。

    Returns:
        含固定表头和尾换行的文本；空输入、只有表头、无有效行或缺少合成域时
        返回 ``None``。

    Raises:
        URL/字符串对象在转换或解析时产生的异常会原样传播。

    Side Effects:
        无。请求头风格输入会使用固定 path、安全位与 expiry 合成数据行，无法
        恢复原输入未携带的 Cookie 属性。
    """
    if cookie_str is None:
        return None
    text = str(cookie_str).strip()
    if not text:
        return None

    lines = text.splitlines()
    if not lines:
        return None

    # 已是 Netscape：过滤表头后的非数据行。
    if lines[0].strip() == NETSCAPE_HEADER:
        body = [ln for ln in lines[1:] if _looks_like_netscape_row(ln.strip())]
        if not body:
            return None
        return NETSCAPE_HEADER + "\n" + "\n".join(body) + "\n"

    # 无表头但已是 tab 数据行。
    tab_body = [ln for ln in lines if _looks_like_netscape_row(ln.strip())]
    if tab_body:
        return NETSCAPE_HEADER + "\n" + "\n".join(tab_body) + "\n"

    # 请求头风格只能在有 URL hostname 时合成 Netscape 行。
    pairs = _cookie_header_pairs(text if "\t" not in text else "")
    if not pairs:
        # 其它分隔方式无法可靠恢复列结构。
        return None

    domain = _domain_for_url(url)
    if not domain:
        return None

    out = [NETSCAPE_HEADER]
    for name, value in pairs:
        # 字段顺序：domain、includeSubdomains、path、secure、expiry、name、value。
        out.append(f"{domain}\tTRUE\t/\tFALSE\t0\t{name}\t{value}")
    return "\n".join(out) + "\n"


def cookie_header_from_raw(cookie_str: str | None) -> str | None:
    """把支持的输入降级为 HTTP Cookie header 文本。

    Args:
        cookie_str: Netscape 文本、tab 数据行或请求头风格文本。

    Returns:
        仅由名称和值拼接的 header，无法提取任何有效 pair 时为 ``None``。

    Side Effects:
        无。降级会丢失域、path、secure 与 expiry 语义；返回值含敏感认证数据，
        只能用于请求，不得写入日志。
    """
    if not cookie_str or not str(cookie_str).strip():
        return None
    text = str(cookie_str).strip()
    if text.startswith(NETSCAPE_HEADER) or "\t" in text:
        pairs: list[str] = []
        for line in text.splitlines():
            if not _looks_like_netscape_row(line.strip()):
                continue
            parts = line.split("\t")
            if len(parts) >= 7:
                pairs.append(f"{parts[5]}={parts[6]}")
        return "; ".join(pairs) if pairs else None
    pairs = _cookie_header_pairs(text)
    if not pairs:
        return None
    return "; ".join(f"{n}={v}" for n, v in pairs)


def write_cookiefile(
    cookie_str: str | None,
    cache_dir: str,
    url: str | None = None,
) -> Optional[str]:
    """创建一次调用专用的临时 Netscape cookiefile。

    Args:
        cookie_str: 待规范化的 Cookie 输入。
        cache_dir: 临时文件所在目录。
        url: 合成域字段时使用的 URL 上下文。

    Returns:
        新文件路径；输入无法形成 Netscape 内容时返回 ``None``。

    Raises:
        OSError: 创建目录或写文件失败。此时不会自动回退到 HTTP header。

    Side Effects:
        创建目录及含敏感数据的文件。文件名包含进程 ID 与随机片段以支持并发；
        调用方必须最终调用 ``cleanup_cookiefile``。
    """
    normalized = normalize_netscape_cookie_text(cookie_str, url=url)
    if not normalized:
        return None
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"cookies_{os.getpid()}_{uuid.uuid4().hex[:12]}.txt")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(normalized)
    return path


def apply_cookies_to_ydl_opts(
    ydl_opts: dict,
    cookie_str: str | None,
    cache_dir: str,
    url: str | None = None,
) -> Optional[str]:
    """把 Cookie 认证配置写入 yt-dlp options。

    Args:
        ydl_opts: 将被原地修改的 options 字典。
        cookie_str: 宿主提供的 Cookie 文本。
        cache_dir: cookiefile 临时目录。
        url: 请求头风格输入的域上下文。

    Returns:
        创建成功的 cookiefile 路径；未创建文件时返回 ``None``，此时可能已设置
        ``http_headers['Cookie']``，也可能输入无有效内容。

    Raises:
        OSError: cookiefile 目录或写入失败。

    Side Effects:
        可能创建敏感临时文件，并原地写入 ``ydl_opts``。header 回退只发生在输入
        无法规范化为文件内容时，不捕获文件写入异常。
    """
    path = write_cookiefile(cookie_str, cache_dir, url=url)
    if path:
        ydl_opts["cookiefile"] = path
        return path

    header = cookie_header_from_raw(cookie_str)
    if header:
        headers = dict(ydl_opts.get("http_headers") or {})
        headers["Cookie"] = header
        ydl_opts["http_headers"] = headers
    return None


def cleanup_cookiefile(path: str | None) -> None:
    """尽力删除本层创建的临时 cookiefile。

    Args:
        path: 可选文件路径；空值直接返回。

    Returns:
        ``None``。

    Side Effects:
        文件存在时尝试删除。存在检查或删除产生的 ``OSError`` 被吞掉，因此调用方
        不能仅凭返回值确认敏感文件已清理。
    """
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
