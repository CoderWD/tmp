"""Hook yt-dlp EJS（YouTube JS Challenge）执行路径，改走 iOS JS 桥接。

iOS 策略：
- 仅启用 node 运行时（由 subprocess hook 虚拟版本 + JavaScriptCore 执行）
- 禁用 deno/bun（依赖 npm import，JSC 无法运行）
- 优先从 BundledPython/ejs/ 加载 EJS lib/core 脚本
"""

from __future__ import annotations

import os
import sys

from ios_debug_log import log, log_preview, log_timing
from ios_js_evaluator import clean_js_runtime_stderr

_EJS_HOOK_INSTALLED = False
_EJS_VERSION = '0.8.0'
_EJS_LIB_FILE = 'yt.solver.lib.min.js'
_EJS_CORE_FILE = 'yt.solver.core.min.js'
_ORIGINAL_BUILTIN_SOURCE = None


def _bundled_ejs_dir() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ejs')


def _load_bundled_ejs_file(filename: str) -> str | None:
    path = os.path.join(_bundled_ejs_dir(), filename)
    if not os.path.isfile(path):
        return None
    with open(path, encoding='utf-8') as handle:
        return handle.read()


def _ios_builtin_source(self, script_type):
    from yt_dlp.extractor.youtube.jsc._builtin.ejs import (
        Script,
        ScriptSource,
        ScriptType,
        ScriptVariant,
    )

    filename = {
        ScriptType.LIB: _EJS_LIB_FILE,
        ScriptType.CORE: _EJS_CORE_FILE,
    }.get(script_type)
    if not filename:
        if _ORIGINAL_BUILTIN_SOURCE is not None:
            return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
        return None

    code = _load_bundled_ejs_file(filename)
    if code:
        log('ejs_hook', f'using bundled EJS {filename} len={len(code)}')
        return Script(
            script_type,
            ScriptVariant.MINIFIED,
            ScriptSource.BUILTIN,
            _EJS_VERSION,
            code,
        )

    log('ejs_hook', f'bundled EJS missing: {filename}, fallback to upstream builtin')
    if _ORIGINAL_BUILTIN_SOURCE is not None:
        return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
    return None


def _ios_run_js_runtime(self, stdin: str) -> str:
    from ios_js_bridge import evaluate_via_bridge, is_bridge_available
    from yt_dlp.extractor.youtube.jsc.provider import JsChallengeProviderError

    provider = getattr(self, 'PROVIDER_NAME', type(self).__name__)
    runtime = getattr(self, 'JS_RUNTIME_NAME', '?')
    log(
        'ejs_hook',
        f'_run_js_runtime provider={provider} runtime={runtime} '
        f'bridge_available={is_bridge_available()} stdin_len={len(stdin or "")}',
    )

    try:
        with log_timing('ejs_hook', f'evaluate provider={provider}'):
            stdout, stderr = evaluate_via_bridge(stdin)
    except Exception as exc:  # noqa: BLE001
        log('ejs_hook', f'bridge error provider={provider}: {exc}')
        raise JsChallengeProviderError(f'iOS JS bridge error: {exc}') from exc

    stderr = clean_js_runtime_stderr(stderr)
    if stderr:
        log_preview('ejs_hook', 'stderr', stderr)
        raise JsChallengeProviderError(f'Error running JS runtime: {stderr.strip()}')
    if not stdout:
        log('ejs_hook', f'empty stdout provider={provider}')
        raise JsChallengeProviderError('JS runtime produced no output')

    log_preview('ejs_hook', f'stdout provider={provider}', stdout)
    return stdout


def _ios_run_deno_via_bridge(self, stdin, options):
    log('ejs_hook', f'_run_deno intercepted (deno unsupported on iOS) options={options}')
    return _ios_run_js_runtime(self, stdin)


def _ios_provider_disabled(self, /) -> bool:
    return False


def should_enable_ejs_hook(force: bool | None = None) -> bool:
    if force is not None:
        return force
    return sys.platform in {'ios', 'tvos', 'visionos', 'watchos'}


def apply_ejs_hook(force: bool | None = None) -> bool:
    """安装 iOS EJS hook。"""
    global _EJS_HOOK_INSTALLED, _ORIGINAL_BUILTIN_SOURCE

    if _EJS_HOOK_INSTALLED:
        return True
    if not should_enable_ejs_hook(force):
        return False

    from yt_dlp.extractor.youtube.jsc._builtin import bun, deno, ejs, node, quickjs

    if _ORIGINAL_BUILTIN_SOURCE is None:
        _ORIGINAL_BUILTIN_SOURCE = ejs.EJSBaseJCP._builtin_source
    ejs.EJSBaseJCP._builtin_source = _ios_builtin_source

    for provider_cls in (node.NodeJCP, deno.DenoJCP, quickjs.QuickJSJCP, bun.BunJCP):
        provider_cls._run_js_runtime = _ios_run_js_runtime
        log('ejs_hook', f'patched {provider_cls.__name__}._run_js_runtime')

    deno.DenoJCP._run_deno = _ios_run_deno_via_bridge
    deno.DenoJCP.is_available = _ios_provider_disabled
    bun.BunJCP.is_available = _ios_provider_disabled
    log('ejs_hook', 'disabled deno/bun providers on iOS')

    _EJS_HOOK_INSTALLED = True
    log('ejs_hook', f'apply_ejs_hook installed bundled_ejs_dir={_bundled_ejs_dir()}')
    return True


def is_ejs_hook_installed() -> bool:
    return _EJS_HOOK_INSTALLED
