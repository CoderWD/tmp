"""Hook yt-dlp EJS（YouTube JS Challenge）执行路径，改走 iOS JS 桥接。

iOS 策略：
- 仅启用 node 运行时（由 subprocess hook 虚拟版本 + JavaScriptCore 执行）
- 禁用 deno/bun（依赖 npm import，JSC 无法运行）
- 优先从 bundled ejs/ 加载 EJS lib/core 脚本
- 强制 output_preprocessed=false，避免 JSC stringify 数 MB player
- nsig / sig 拆成两次 JSC 调用；失败只 yield error，避免污染后 raise 再崩
"""

from __future__ import annotations

import collections
import json
import os
import sys

from ios_debug_log import log, log_preview, log_timing
from ios_js_evaluator import clean_js_runtime_stderr

_EJS_HOOK_INSTALLED = False
_EJS_VERSION = '0.8.0'
_EJS_LIB_FILE = 'yt.solver.lib.min.js'
_EJS_CORE_FILE = 'yt.solver.core.min.js'
_ORIGINAL_BUILTIN_SOURCE = None


def _bundled_ejs_dir() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ejs')


def _load_bundled_ejs_file(filename: str) -> str | None:
    path = os.path.join(_bundled_ejs_dir(), filename)
    if not os.path.isfile(path):
        return None
    with open(path, encoding='utf-8') as handle:
        return handle.read()


def _ios_builtin_source(self, script_type):
    from yt_dlp.extractor.youtube.jsc._builtin.ejs import (
        Script,
        ScriptSource,
        ScriptType,
        ScriptVariant,
    )

    filename = {
        ScriptType.LIB: _EJS_LIB_FILE,
        ScriptType.CORE: _EJS_CORE_FILE,
    }.get(script_type)
    if not filename:
        if _ORIGINAL_BUILTIN_SOURCE is not None:
            return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
        return None

    code = _load_bundled_ejs_file(filename)
    if code:
        log('ejs_hook', f'using bundled EJS {filename} len={len(code)}')
        return Script(
            script_type,
            ScriptVariant.MINIFIED,
            ScriptSource.BUILTIN,
            _EJS_VERSION,
            code,
        )

    log('ejs_hook', f'bundled EJS missing: {filename}, fallback to upstream builtin')
    if _ORIGINAL_BUILTIN_SOURCE is not None:
        return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
    return None


def _disable_ejs_preprocessed_output(stdin: str) -> str:
    """禁止 EJS 在 stdout 里回传整段 preprocessed_player。"""
    original = stdin
    for old, new in (
        ('"output_preprocessed": true', '"output_preprocessed": false'),
        ('"output_preprocessed":true', '"output_preprocessed":false'),
        ("'output_preprocessed': true", "'output_preprocessed': false"),
        ("'output_preprocessed':true", "'output_preprocessed':false"),
    ):
        if old in stdin:
            stdin = stdin.replace(old, new)
    if stdin != original:
        log(
            'ejs_hook',
            f'disabled output_preprocessed stdin_len {len(original)}->{len(stdin)}',
        )
    else:
        log('ejs_hook', 'output_preprocessed rewrite: pattern not found (ok if cached player)')
    return stdin


def _stdout_has_nul(stdout: str) -> bool:
    return ('\x00' in stdout) or ('\\u0000' in stdout)


def _ios_run_js_runtime(self, stdin: str) -> str:
    """只负责桥接执行；不做 raise（由 _ios_real_bulk_solve 消化错误）。"""
    from ios_js_bridge import evaluate_via_bridge, is_bridge_available
    from yt_dlp.extractor.youtube.jsc.provider import JsChallengeProviderError

    provider = getattr(self, 'PROVIDER_NAME', type(self).__name__)
    runtime = getattr(self, 'JS_RUNTIME_NAME', '?')
    stdin = _disable_ejs_preprocessed_output(stdin or '')
    log(
        'ejs_hook',
        f'_run_js_runtime provider={provider} runtime={runtime} '
        f'bridge_available={is_bridge_available()} stdin_len={len(stdin)}',
    )

    try:
        with log_timing('ejs_hook', f'evaluate provider={provider}'):
            stdout, stderr = evaluate_via_bridge(stdin)
    except Exception as exc:  # noqa: BLE001
        log('ejs_hook', f'bridge error provider={provider}: {type(exc).__name__}')
        raise JsChallengeProviderError('iOS JS bridge error') from None

    stderr = clean_js_runtime_stderr(stderr)
    if stderr:
        log('ejs_hook', 'stderr non-empty after clean')
        raise JsChallengeProviderError('Error running JS runtime')
    if not stdout:
        log('ejs_hook', f'empty stdout provider={provider}')
        raise JsChallengeProviderError('JS runtime produced no output')

    stdout = str(stdout)
    log('ejs_hook', f'_run_js_runtime raw stdout_len={len(stdout)} has_nul={_stdout_has_nul(stdout)}')
    return stdout


def _ios_run_deno_via_bridge(self, stdin, options):
    log('ejs_hook', f'_run_deno intercepted (deno unsupported on iOS) options={options}')
    return _ios_run_js_runtime(self, stdin)


def _parse_ejs_output(stdout: str, expected_count: int):
    """返回 (responses_list|None, error_message|None)。永不抛与脏对象相关的复杂异常。"""
    if _stdout_has_nul(stdout):
        return None, 'EJS stdout contains NUL sequences'
    try:
        obj = json.loads(stdout)
    except Exception:  # noqa: BLE001
        return None, 'EJS stdout is not valid JSON'
    if not isinstance(obj, dict):
        return None, 'EJS stdout JSON root must be object'
    if obj.get('type') == 'error':
        err = obj.get('error')
        return None, err if isinstance(err, str) and err else 'EJS error'
    responses = obj.get('responses')
    if not isinstance(responses, list):
        return None, 'EJS stdout missing responses'
    if len(responses) != expected_count:
        return None, f'EJS response count mismatch {len(responses)}!={expected_count}'
    for idx, resp in enumerate(responses):
        if not isinstance(resp, dict):
            return None, f'EJS response[{idx}] not object'
        data = resp.get('data')
        if isinstance(data, dict):
            for key in data:
                if isinstance(key, str) and '\x00' in key:
                    return None, f'EJS response[{idx}] has NUL keys'
    return responses, None


def _ios_real_bulk_solve(self, /, requests):
    """按 challenge type 拆开跑 JSC；单路失败只 yield error，不把异常抛出生成器。"""
    from yt_dlp.extractor.youtube.jsc.provider import (
        JsChallengeProviderError,
        JsChallengeProviderResponse,
        JsChallengeResponse,
        JsChallengeType,
        NChallengeOutput,
        SigChallengeOutput,
    )

    grouped: dict[str, list] = collections.defaultdict(list)
    for request in requests:
        grouped[request.input.player_url].append(request)

    for player_url, grouped_requests in grouped.items():
        player = None
        cached = False
        if self._ENABLE_PREPROCESSED_PLAYER_CACHE:
            player = self.ie.cache.load(self._CACHE_SECTION, f'player:{player_url}')
        if player:
            cached = True
        else:
            video_id = next((request.video_id for request in grouped_requests), None)
            player = self._get_player(video_id, player_url)

        self.logger.info(f'Solving JS challenges using {self.JS_RUNTIME_NAME} (ios split)')

        by_type: dict = collections.defaultdict(list)
        for req in grouped_requests:
            by_type[req.type].append(req)

        # 先 n 后 sig：nsig 更常成功；sig 若污染进程，至少 n 已交出
        type_order = [t for t in (JsChallengeType.N, JsChallengeType.SIG) if t in by_type]
        for extra in by_type:
            if extra not in type_order:
                type_order.append(extra)

        for challenge_type in type_order:
            type_requests = by_type[challenge_type]
            log(
                'ejs_hook',
                f'bulk_solve begin type={challenge_type.value} count={len(type_requests)} '
                f'player_cached={cached}',
            )
            # iOS JSC：nsig 稳定；sig 第二次进桥接/JSC 会把进程打崩（PyTuple_SetItem /
            # PythonKit 编组 ~3MB stdin）。先跳过 sig，让 extract 靠 nsig 继续。
            if challenge_type is JsChallengeType.SIG:
                log(
                    'ejs_hook',
                    'bulk_solve SKIP type=sig on iOS JSC '
                    '(second large evaluate crashes process; nsig-only fallback)',
                )
                soft_err = JsChallengeProviderError('sig challenge skipped on iOS JSC')
                for request in type_requests:
                    yield JsChallengeProviderResponse(request=request, error=soft_err)
                continue
            try:
                stdin = self._construct_stdin(player, cached, type_requests)
                stdout = self._run_js_runtime(stdin)
                responses, err = _parse_ejs_output(stdout, len(type_requests))
                if err is not None or responses is None:
                    log('ejs_hook', f'bulk_solve type={challenge_type.value} soft-fail: {err}')
                    soft_err = JsChallengeProviderError(err or 'EJS soft-fail')
                    for request in type_requests:
                        yield JsChallengeProviderResponse(request=request, error=soft_err)
                    continue

                log_preview('ejs_hook', f'stdout type={challenge_type.value}', stdout)
                for request, response_data in zip(type_requests, responses, strict=True):
                    if response_data.get('type') == 'error':
                        msg = response_data.get('error')
                        yield JsChallengeProviderResponse(
                            request=request,
                            error=JsChallengeProviderError(
                                msg if isinstance(msg, str) and msg else 'challenge error'
                            ),
                        )
                        continue
                    data = response_data.get('data') or {}
                    if not isinstance(data, dict):
                        yield JsChallengeProviderResponse(
                            request=request,
                            error=JsChallengeProviderError('challenge data not object'),
                        )
                        continue
                    yield JsChallengeProviderResponse(
                        request=request,
                        response=JsChallengeResponse(
                            request.type,
                            (
                                NChallengeOutput(data)
                                if request.type is JsChallengeType.N
                                else SigChallengeOutput(data)
                            ),
                        ),
                    )
                log('ejs_hook', f'bulk_solve ok type={challenge_type.value}')
            except Exception as exc:  # noqa: BLE001
                # 故意不把原始 exc 放进 message/format，降低二次 str 崩溃概率
                log(
                    'ejs_hook',
                    f'bulk_solve type={challenge_type.value} exception={type(exc).__name__}',
                )
                soft_err = JsChallengeProviderError(
                    f'EJS {challenge_type.value} failed: {type(exc).__name__}'
                )
                for request in type_requests:
                    yield JsChallengeProviderResponse(request=request, error=soft_err)


def _ios_provider_disabled(self, /) -> bool:
    return False


def should_enable_ejs_hook(force: bool | None = None) -> bool:
    if force is not None:
        return force
    return sys.platform in {'ios', 'tvos', 'visionos', 'watchos'}


def apply_ejs_hook(force: bool | None = None) -> bool:
    """安装 iOS EJS hook。"""
    global _EJS_HOOK_INSTALLED, _ORIGINAL_BUILTIN_SOURCE

    if _EJS_HOOK_INSTALLED:
        return True
    if not should_enable_ejs_hook(force):
        return False

    from yt_dlp.extractor.youtube.jsc._builtin import bun, deno, ejs, node, quickjs

    if _ORIGINAL_BUILTIN_SOURCE is None:
        _ORIGINAL_BUILTIN_SOURCE = ejs.EJSBaseJCP._builtin_source
    ejs.EJSBaseJCP._builtin_source = _ios_builtin_source
    ejs.EJSBaseJCP._real_bulk_solve = _ios_real_bulk_solve

    for provider_cls in (node.NodeJCP, deno.DenoJCP, quickjs.QuickJSJCP, bun.BunJCP):
        provider_cls._run_js_runtime = _ios_run_js_runtime
        log('ejs_hook', f'patched {provider_cls.__name__}._run_js_runtime')

    deno.DenoJCP._run_deno = _ios_run_deno_via_bridge
    deno.DenoJCP.is_available = _ios_provider_disabled
    bun.BunJCP.is_available = _ios_provider_disabled
    log('ejs_hook', 'disabled deno/bun providers on iOS')
    log('ejs_hook', 'patched EJSBaseJCP._real_bulk_solve (split n/sig, soft-fail)')

    _EJS_HOOK_INSTALLED = True
    log('ejs_hook', f'apply_ejs_hook installed bundled_ejs_dir={_bundled_ejs_dir()}')
    return True


def is_ejs_hook_installed() -> bool:
    return _EJS_HOOK_INSTALLED
