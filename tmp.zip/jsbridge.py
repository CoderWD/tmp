import os
import sys
import json


def run_python(param_json_string):
    print(f"receive param from js: {param_json_string}")
    try:
        param = json.loads(param_json_string)
        print(f"receive param from js json:: {param}")
        result = {
            "success": True,
            "code": 0
        }
        return json.dumps(result, indent=4)
    except Exception as e:
        # 异常处理代码
        print(f"An error occurred: {e}")
        result = {
            "success": False,
            "code": -1,
            "message": f"An error occurred: {e}"
        }
        return json.dumps(result, indent=4)
