"""yt-dlp 媒体解析入口（供 iOS Python 运行时调用）。

Swift `PythonMediaExtractor` 调用约定：
- extract(url, cookie_str, json_param_str, library_path) → ExtractorMedia 兼容 info JSON 或 {url, errMsg}
- search(query, cookie_str, json_param_str, library_path) → {query, search_type, entries} 或 {url, errMsg}
"""

import json
import os
import re
import sys

# iOS AVPlayer 原生可播编码优先：H.264(avc1) + AAC(mp4a)，容器 mp4/m4a。
COMPAT_FORMAT_SPEC = (
    "bv*[vcodec^=avc1][ext=mp4]+ba[acodec^=mp4a][ext=m4a]/"
    "bv*[vcodec^=avc1]+ba[acodec^=mp4a]/"
    "b[vcodec^=avc1][acodec^=mp4a][ext=mp4]/"
    "b[ext=mp4]/"
    "bv*+ba/b"
)
SCRIPT_BUILD_ID = "2026-07-16-hls-segment-probe-v1"

SEARCH_PREFIX_MAP = {
    "youtube": "ytsearch",
    "soundcloud": "scsearch",
}

_DIRECT_MEDIA_EXTENSIONS = (
    ".mp4",
    ".m4v",
    ".mov",
    ".webm",
    ".mkv",
    ".mp3",
    ".m4a",
    ".aac",
    ".flac",
    ".wav",
    ".opus",
    ".m3u8",
    ".mpd",
)


def _setup_paths():
    root = os.path.dirname(os.path.abspath(__file__))
    if root not in sys.path:
        sys.path.insert(0, root)


def _install_ios_hooks():
    """在导入 yt_dlp 之前安装 iOS hook。"""
    _setup_paths()
    try:
        from ios_debug_log import log
        from ios_subprocess_hook import apply_ios_subprocess_hook

        log("extract_media", "installing ios_subprocess_hook")
        apply_ios_subprocess_hook(force=True)
    except Exception as exc:  # noqa: BLE001
        sys.stderr.write(f"[extract_media] ios_subprocess_hook failed: {exc}\n")


def _install_ejs_hook():
    try:
        from ios_debug_log import log
        from ios_ejs_hook import apply_ejs_hook

        log("extract_media", "installing ios_ejs_hook")
        installed = apply_ejs_hook(force=True)
        log("extract_media", f"ios_ejs_hook installed={installed}")
    except Exception as exc:  # noqa: BLE001
        sys.stderr.write(f"[extract_media] ios_ejs_hook failed: {exc}\n")


def _response(ok, url, error=None, **fields):
    from ios_debug_log import get_log

    payload = {
        "ok": ok,
        "url": url,
        "error": error,
        "debug_log": get_log(),
    }
    payload.update(fields)
    return json.dumps(payload, ensure_ascii=False)


def _exception_json(url, err_msg):
    """与 Swift ExtractorException(url:errMsg:) 对齐；附带 debug_log 便于真机排查。"""
    from ios_debug_log import get_log

    return json.dumps(
        {
            "url": url or "",
            "errMsg": str(err_msg),
            "debug_log": get_log(),
        },
        ensure_ascii=False,
    )


def _cache_dir(library_path=None):
    if library_path and str(library_path).strip():
        cache = os.path.join(str(library_path).strip(), ".cache")
    else:
        root = os.path.dirname(os.path.abspath(__file__))
        cache = os.path.join(root, ".cache")
    os.makedirs(cache, exist_ok=True)
    try:
        os.chmod(cache, 0o700)
    except OSError:
        pass
    return cache


def _base_ydl_opts(cache_dir, format_spec=None, quiet=False):
    opts = {
        "quiet": quiet,
        "no_warnings": quiet,
        "verbose": not quiet,
        "skip_download": True,
        "noplaylist": True,
        "socket_timeout": 30,
        "cachedir": cache_dir,
        # iOS 使用虚拟 node + JavaScriptCore；禁用默认 deno（npm 脚本 JSC 无法执行）
        "js_runtimes": {"node": {}},
        "remote_components": ["ejs:github"],
    }
    if format_spec:
        opts["format"] = format_spec
    return opts


def _recommended_urls(info):
    """与 yt-dlp -g（forceurl）一致：合并格式时返回多条直链。"""
    requested = info.get("requested_formats")
    if requested:
        urls = []
        for fmt in requested:
            url = fmt.get("url")
            if not url:
                continue
            urls.append(url + fmt.get("play_path", ""))
        return urls

    url = info.get("url")
    if url:
        return [url + info.get("play_path", "")]
    return []


def _recommended_from_selection(info, ydl, format_spec):
    """在完整 formats 已解析后，按 format_spec 选择推荐直链。"""
    from ios_debug_log import log

    formats = info.get("formats") or []
    spec = format_spec or ydl._default_format_spec(info)
    try:
        selected = ydl._select_formats(formats, ydl.build_format_selector(spec))
    except Exception as exc:
        log("extract_media", f"format selection failed spec={spec!r}: {exc}")
        return [], spec

    if not selected:
        log("extract_media", f"format selection empty spec={spec!r}")
        return [], spec

    urls = []
    for item in selected:
        if isinstance(item, dict):
            urls.extend(_recommended_urls(item))

    seen = set()
    unique = []
    for url in urls:
        if url not in seen:
            seen.add(url)
            unique.append(url)

    log(
        "extract_media",
        f"format selection selected={len(selected)} urls={len(unique)} spec={spec!r}",
    )
    return unique, spec


def _cleanup_extract(ydl, cookies_file_path):
    if ydl is not None:
        try:
            ydl.__exit__(None, None, None)
        except Exception:
            pass
    from ios_cookies import cleanup_cookiefile

    cleanup_cookiefile(cookies_file_path)


def _run_extract(url, cookie_str="", format_spec=None, library_path=None, quiet=False):
    """执行 extract_info，成功时返回 (info_dict, ydl, cookies_file_path, ydl_opts)。

    失败时返回错误 JSON 字符串。
    """
    from ios_cookies import apply_cookies_to_ydl_opts
    from ios_debug_log import clear_log, log

    clear_log()
    log(
        "extract_media",
        f"script_build={SCRIPT_BUILD_ID} start url={url} "
        f"cookie_lines={len(str(cookie_str or '').splitlines())} format_spec={format_spec!r}",
    )

    if not url or not str(url).strip():
        return _exception_json(url or "", "URL is empty")

    _install_ios_hooks()

    try:
        from ios_js_bridge import is_bridge_available

        log("extract_media", f"js_bridge_available={is_bridge_available()}")
    except Exception as exc:  # noqa: BLE001
        log("extract_media", f"js_bridge import check failed: {exc}")

    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        log("extract_media", f"import yt_dlp failed: {exc}")
        return _exception_json(url, f"import yt_dlp failed: {exc}")

    _install_ejs_hook()
    try:
        from ios_ejs_hook import is_ejs_hook_installed

        log("extract_media", f"ejs_hook_installed={is_ejs_hook_installed()}")
    except Exception as exc:  # noqa: BLE001
        log("extract_media", f"ejs_hook status check failed: {exc}")

    cache_dir = _cache_dir(library_path)
    ydl_opts = _base_ydl_opts(cache_dir, format_spec=format_spec, quiet=quiet)
    log("extract_media", "ydl_opts js_runtimes=node remote_components=ejs:github")

    cookies_file_path = apply_cookies_to_ydl_opts(
        ydl_opts, cookie_str, cache_dir, url=url
    )
    if cookies_file_path:
        log("extract_media", f"using cookiefile={cookies_file_path}")
    elif ydl_opts.get("http_headers", {}).get("Cookie"):
        log("extract_media", "using Cookie http_header fallback")
    else:
        log("extract_media", "no cookies")

    ydl = None
    info = None
    try:
        log("extract_media", "YoutubeDL.extract_info begin")
        ydl = YoutubeDL(ydl_opts)
        ydl.__enter__()
        info = ydl.extract_info(url, download=False)
        log("extract_media", f"YoutubeDL.extract_info done info_present={bool(info)}")
    except Exception as exc:
        log("extract_media", f"extract_info failed: {exc}")
        _cleanup_extract(ydl, cookies_file_path)
        return _exception_json(url, str(exc))

    if not info:
        _cleanup_extract(ydl, cookies_file_path)
        return _exception_json(url, "No info returned")

    return info, ydl, cookies_file_path, ydl_opts


def _ensure_ext(info):
    ext = info.get("ext")
    if ext and str(ext).strip() and str(ext) != "unknown":
        return str(ext)
    formats = info.get("formats") or []
    for fmt in reversed(formats):
        if not isinstance(fmt, dict):
            continue
        candidate = fmt.get("ext")
        if candidate and str(candidate).strip() and str(candidate) != "unknown":
            return str(candidate)
    return "mp4"


def _sanitize_format_for_ios(fmt):
    """保证 Swift ExtractorMedia.Format 必填字段存在。"""
    if not isinstance(fmt, dict):
        return None
    url = fmt.get("url")
    if not url:
        return None
    out = dict(fmt)
    out["url"] = str(url)
    out["ext"] = str(fmt.get("ext") or "unknown")
    out["protocol"] = str(fmt.get("protocol") or "https")
    height = fmt.get("height")
    width = fmt.get("width")
    if height is not None:
        try:
            h = int(height)
            if h > 0:
                out["height"] = h
        except (TypeError, ValueError):
            pass
    if not out.get("resolution"):
        if width and height:
            out["resolution"] = f"{width}x{height}"
        elif fmt.get("format_note"):
            out["resolution"] = str(fmt.get("format_note"))
    # 透传体积供 Swift 清晰度列表展示（精确值优先）
    filesize = fmt.get("filesize")
    if filesize is None:
        filesize = fmt.get("filesize_approx")
        if filesize is not None:
            try:
                out["filesize_approx"] = int(filesize)
            except (TypeError, ValueError):
                pass
    else:
        try:
            out["filesize"] = int(filesize)
        except (TypeError, ValueError):
            pass
    # 透传 codec，便于 Swift 区分纯音频 / 纯视频 / 合成轨
    for key in ("vcodec", "acodec"):
        val = fmt.get(key)
        if val is not None:
            out[key] = str(val)
    return out


def _merge_cookie_header_parts(*headers):
    """合并多个 Cookie 头，同名后者覆盖。"""
    merged = {}
    for header in headers:
        if not header:
            continue
        for piece in str(header).split(";"):
            piece = piece.strip()
            if not piece or "=" not in piece:
                continue
            name, value = piece.split("=", 1)
            name = name.strip()
            if name:
                merged[name] = value.strip()
    if not merged:
        return None
    return "; ".join(f"{k}={v}" for k, v in merged.items())


def _cookie_header_from_ydl(ydl, sample_urls):
    """从 YoutubeDL 内存 cookiejar 取 Cookie（含 extract 过程中 Set-Cookie，比原始 cookiefile 更全）。"""
    if ydl is None:
        return None
    jar = getattr(ydl, "cookiejar", None)
    if jar is None:
        return None
    urls = list(sample_urls or [])
    urls.extend(
        (
            "https://www.youtube.com/",
            "https://music.youtube.com/",
            "https://www.googlevideo.com/",
        )
    )
    parts = []
    for sample in urls:
        if not sample:
            continue
        try:
            header = jar.get_cookie_header(str(sample))
            if header:
                parts.append(header)
        except Exception:  # noqa: BLE001
            continue
    return _merge_cookie_header_parts(*parts)


def _cookie_header_for_response(ydl, cookies_file_path, cookie_str, sample_urls=None):
    """提取阶段 Cookie 头，供 Swift 直链/HLS 下载复用（sanitize 会剥离 format 内 Cookie）。"""
    from ios_cookies import cookie_header_from_raw
    from ios_debug_log import log

    from_jar = _cookie_header_from_ydl(ydl, sample_urls)
    from_file = None
    if cookies_file_path:
        try:
            with open(cookies_file_path, encoding="utf-8") as handle:
                from_file = cookie_header_from_raw(handle.read())
        except OSError as exc:
            log("extract_media", f"cookiefile read failed: {exc}")
    from_raw = cookie_header_from_raw(cookie_str)
    header = _merge_cookie_header_parts(from_jar, from_file, from_raw)
    log(
        "extract_media",
        f"cookie_header sources jar={'yes' if from_jar else 'no'} "
        f"file={'yes' if from_file else 'no'} raw={'yes' if from_raw else 'no'} "
        f"merged_len={len(header) if header else 0}",
    )
    return header


def _info_json_for_ios(info, cookie_header=None):
    """返回 ExtractorMedia 可解码的 info JSON 字符串。"""
    from yt_dlp import YoutubeDL

    YoutubeDL.post_extract(info)
    sanitized = YoutubeDL.sanitize_info(info)
    if not isinstance(sanitized, dict):
        sanitized = dict(info)

    formats = []
    for fmt in sanitized.get("formats") or []:
        cleaned = _sanitize_format_for_ios(fmt)
        if cleaned:
            formats.append(cleaned)
    sanitized["formats"] = formats
    try:
        from ios_debug_log import log

        with_height = sum(1 for f in formats if f.get("height"))
        with_size = sum(1 for f in formats if f.get("filesize") or f.get("filesize_approx"))
        log(
            "extract_media",
            f"sanitize formats={len(formats)} with_height={with_height} with_filesize={with_size}",
        )
    except Exception:
        pass
    sanitized["ext"] = _ensure_ext(sanitized)
    if not sanitized.get("title"):
        sanitized["title"] = sanitized.get("id") or "Unknown"
    if cookie_header:
        sanitized["cookie_header"] = cookie_header
    return json.dumps(sanitized, ensure_ascii=False)


def extract(url, cookie_str="", json_param_str="", library_path=""):
    """iOS 解析入口：成功 → info JSON；失败 → {url, errMsg}。

    参数与旧 main.extract 对齐，便于 Swift 直接替换模块名。
    json_param_str 预留（可传 format_spec 等）；当前主要消费 library_path。
    """
    format_spec = None
    if json_param_str and str(json_param_str).strip():
        try:
            params = json.loads(json_param_str)
            if isinstance(params, dict):
                raw = params.get("format_spec") or params.get("format")
                if raw and str(raw).strip():
                    format_spec = str(raw).strip()
        except Exception:
            pass

    result = _run_extract(
        url,
        cookie_str=cookie_str,
        format_spec=None,  # 不约束 formats；推荐轨由 Swift / 后续 download 选择
        library_path=library_path,
        quiet=True,
    )
    if isinstance(result, str):
        return result

    info, ydl, cookies_file_path, _ydl_opts = result
    try:
        from ios_debug_log import log
        from ios_format_probe import filter_unreachable_formats, strip_storyboard_formats

        raw_formats = info.get("formats") or []
        formats, removed = filter_unreachable_formats(raw_formats)
        formats = strip_storyboard_formats(formats)
        info["formats"] = formats
        # format_spec 预留：记录一次推荐选择日志，不改变返回结构
        if format_spec or COMPAT_FORMAT_SPEC:
            _recommended_from_selection(info, ydl, format_spec or COMPAT_FORMAT_SPEC)
        sample_urls = [
            str(fmt.get("url"))
            for fmt in formats
            if isinstance(fmt, dict) and fmt.get("url")
        ][:8]
        cookie_header = _cookie_header_for_response(
            ydl, cookies_file_path, cookie_str, sample_urls=sample_urls
        )
        log(
            "extract_media",
            f"extract success title={info.get('title')!r} "
            f"formats={len(formats)} probe_removed={removed} "
            f"cookie_header={'yes' if cookie_header else 'no'} "
            f"cookie_len={len(cookie_header) if cookie_header else 0}",
        )
        return _info_json_for_ios(info, cookie_header=cookie_header)
    except Exception as exc:
        from ios_debug_log import log

        log("extract_media", f"extract post-process failed: {exc}")
        return _exception_json(url, str(exc))
    finally:
        _cleanup_extract(ydl, cookies_file_path)


def extract_full(url, cookie_str="", format_spec=None, library_path=""):
    """解析媒体 URL，返回与 yt-dlp -j 等价的 info 及 -g 推荐直链（含 ok/debug_log）。"""
    effective_spec = format_spec if (format_spec and str(format_spec).strip()) else COMPAT_FORMAT_SPEC
    result = _run_extract(
        url,
        cookie_str=cookie_str,
        format_spec=None,
        library_path=library_path,
        quiet=False,
    )
    if isinstance(result, str):
        # _run_extract 失败返回 errMsg 风格；extract_full 对外保持 ok/error
        try:
            payload = json.loads(result)
            err = payload.get("errMsg") or payload.get("error") or result
            return _response(False, url, error=err)
        except Exception:
            return _response(False, url, error=result)

    info, ydl, cookies_file_path, ydl_opts = result
    try:
        from ios_debug_log import log
        from ios_format_probe import (
            filter_unreachable_formats,
            filter_unreachable_urls,
            strip_storyboard_formats,
        )
        from yt_dlp import YoutubeDL

        raw_formats = info.get("formats") or []
        log(
            "extract_media",
            f"extract_full raw_formats={len(raw_formats)} "
            f"storyboard={sum(1 for f in raw_formats if (f.get('protocol') or '').lower() == 'mhtml')}",
        )

        formats, removed_count = filter_unreachable_formats(raw_formats)
        formats = strip_storyboard_formats(formats)
        info["formats"] = formats

        filtered_recommended, used_format_spec = _recommended_from_selection(
            info, ydl, effective_spec
        )
        default_headers = info.get("http_headers") or {}
        filtered_recommended = filter_unreachable_urls(
            filtered_recommended, headers=default_headers
        )

        YoutubeDL.post_extract(info)
        sanitized = YoutubeDL.sanitize_info(info)

        log(
            "extract_media",
            f"extract_full success title={info.get('title')!r} "
            f"raw_formats={len(raw_formats)} after_probe={len(formats)} "
            f"format_probe_removed={removed_count} recommended_urls={len(filtered_recommended)} "
            f"format_spec={used_format_spec!r}",
        )
        return _response(
            True,
            url,
            info=sanitized,
            recommended_urls=filtered_recommended,
            format_spec=used_format_spec,
            format_count=len(formats),
        )
    except Exception as exc:
        import traceback

        from ios_debug_log import log

        log("extract_media", f"extract_full post-process failed: {exc}")
        log("extract_media", traceback.format_exc())
        return _response(False, url, error=str(exc))
    finally:
        _cleanup_extract(ydl, cookies_file_path)


def extract_summary(url, cookie_str="", library_path=""):
    """精简元数据（调试用），不含完整 formats。"""
    result = _run_extract(url, cookie_str=cookie_str, library_path=library_path, quiet=True)
    if isinstance(result, str):
        try:
            payload = json.loads(result)
            err = payload.get("errMsg") or payload.get("error") or result
            return _response(False, url, error=err)
        except Exception:
            return _response(False, url, error=result)

    info, ydl, cookies_file_path, _ydl_opts = result
    try:
        from ios_debug_log import log

        formats = info.get("formats") or []
        vcodec = info.get("vcodec")
        media_kind = "video" if vcodec and vcodec != "none" else "audio"
        filesize = info.get("filesize") or info.get("filesize_approx")
        uploader = info.get("uploader") or info.get("channel") or info.get("artist")
        log(
            "extract_media",
            f"summary success title={info.get('title')!r} formats={len(formats)} kind={media_kind}",
        )
        return _response(
            True,
            url,
            title=info.get("title"),
            id=info.get("id"),
            extractor=info.get("extractor"),
            duration=info.get("duration"),
            format_count=len(formats),
            thumbnail=info.get("thumbnail"),
            uploader=uploader,
            filesize=filesize,
            media_kind=media_kind,
        )
    finally:
        _cleanup_extract(ydl, cookies_file_path)


def _upgrade_thumbnail_url(url, entry=None):
    if not url or not isinstance(url, str):
        return url
    if "sndcdn.com" in url:
        url = re.sub(r"-t\d+x\d+\.", "-t500x500.", url)
        url = re.sub(r"-(?:large|small|badge|tiny|mini)\.", "-t500x500.", url)
        return url
    if "ytimg.com" in url or (entry and entry.get("ie_key") == "Youtube"):
        video_id = None
        if entry:
            raw_id = entry.get("id")
            if isinstance(raw_id, str) and len(raw_id) == 11 and " " not in raw_id:
                video_id = raw_id
        if not video_id:
            match = re.search(r"/vi/([^/]+)/", url)
            video_id = match.group(1) if match else None
        if video_id:
            return f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
    return url


def _pick_thumbnail(entry):
    thumbs = entry.get("thumbnails") or []
    candidates = []
    if isinstance(thumbs, list):
        for thumb_item in thumbs:
            if not isinstance(thumb_item, dict):
                continue
            thumb_url = thumb_item.get("url")
            if not thumb_url:
                continue
            width = thumb_item.get("width") or 0
            height = thumb_item.get("height") or 0
            candidates.append((width * height, thumb_url))

    single = entry.get("thumbnail")
    if single:
        candidates.append((0, single))

    if not candidates:
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    return _upgrade_thumbnail_url(candidates[0][1], entry)


def _normalize_search_entry(entry):
    if not entry or not isinstance(entry, dict):
        return None
    entry_id = entry.get("id")
    webpage_url = entry.get("webpage_url") or entry.get("url")
    if not webpage_url and entry_id:
        if isinstance(entry_id, str) and entry_id.startswith("http"):
            webpage_url = entry_id
        elif entry.get("ie_key") == "Youtube":
            webpage_url = f"https://www.youtube.com/watch?v={entry_id}"
    if not webpage_url:
        return None
    return {
        "id": entry_id,
        "title": entry.get("title") or entry.get("fulltitle") or "",
        "url": webpage_url,
        "webpage_url": webpage_url,
        "thumbnail": _pick_thumbnail(entry),
        "duration": entry.get("duration"),
        "uploader": entry.get("uploader") or entry.get("channel") or entry.get("uploader_id"),
        "view_count": entry.get("view_count"),
    }


def search(query, cookie_str="", json_param_str="", library_path=""):
    """站点搜索（YouTube / SoundCloud），返回 MediaSearchResult 兼容 JSON。"""
    from ios_cookies import apply_cookies_to_ydl_opts, cleanup_cookiefile
    from ios_debug_log import clear_log, log

    clear_log()
    cookies_file_path = None
    try:
        if not query or not str(query).strip():
            return _exception_json(query or "", "Search query is empty")

        limit = 20
        search_type = "youtube"
        if json_param_str and str(json_param_str).strip():
            try:
                params = json.loads(json_param_str)
                limit = int(params.get("limit", limit))
                search_type = str(params.get("type", search_type)).lower()
            except Exception as parse_error:
                log("extract_media", f"search param parse warning: {parse_error}")

        limit = max(1, min(limit, 50))
        prefix = SEARCH_PREFIX_MAP.get(search_type, "ytsearch")
        search_url = f"{prefix}{limit}:{query.strip()}"

        _install_ios_hooks()
        try:
            from yt_dlp import YoutubeDL
        except Exception as exc:
            return _exception_json(query, f"import yt_dlp failed: {exc}")

        _install_ejs_hook()
        cache_dir = _cache_dir(library_path)
        ydl_opts = {
            "socket_timeout": 20,
            "quiet": True,
            "no_warnings": True,
            "cachedir": cache_dir,
            "noplaylist": False,
            "extract_flat": "in_playlist",
            "js_runtimes": {"node": {}},
            "remote_components": ["ejs:github"],
        }
        cookies_file_path = apply_cookies_to_ydl_opts(
            ydl_opts, cookie_str, cache_dir, url=f"https://www.{search_type}.com"
        )

        with YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(search_url, download=False)

        entries = []
        if info_dict:
            for entry in info_dict.get("entries") or []:
                normalized = _normalize_search_entry(entry)
                if normalized and normalized.get("title"):
                    entries.append(normalized)

        result = {
            "query": query.strip(),
            "search_type": search_type,
            "entries": entries,
        }
        log("extract_media", f"search ok type={search_type} entries={len(entries)}")
        return json.dumps(result, ensure_ascii=False)

    except Exception as exc:
        log("extract_media", f"search error: {exc}")
        return _exception_json(query or "", str(exc))
    finally:
        cleanup_cookiefile(cookies_file_path)


def _is_likely_direct_media_url(url):
    from urllib.parse import urlparse

    path = urlparse(url).path.lower()
    return any(path.endswith(ext) for ext in _DIRECT_MEDIA_EXTENSIONS)


def check_url_support(url):
    """检查 URL 是否有 yt-dlp 提取器支持（仅匹配提取器，不联网、不解析）。"""
    from ios_debug_log import clear_log, log

    clear_log()

    if not url or not str(url).strip():
        return _response(False, url or "", supported=False, error="URL is empty")

    url = str(url).strip()
    _install_ios_hooks()

    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        log("extract_media", f"check_url_support import yt_dlp failed: {exc}")
        return _response(False, url, supported=False, error=f"import yt_dlp failed: {exc}")

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
    }
    ydl = YoutubeDL(ydl_opts)
    ydl.add_default_info_extractors()

    matched_key = None
    for key, ie in ydl._ies.items():
        if key in ("end", "Generic"):
            continue
        if ie.suitable(url):
            matched_key = key
            break

    if matched_key:
        log("extract_media", f"check_url_support matched extractor={matched_key}")
        return _response(True, url, supported=True, extractor=matched_key)

    generic = ydl._ies.get("generic")
    if generic and generic.suitable(url) and _is_likely_direct_media_url(url):
        log("extract_media", "check_url_support matched generic direct media")
        return _response(True, url, supported=True, extractor="generic")

    log("extract_media", "check_url_support no suitable extractor")
    return _response(True, url, supported=False, extractor=None)
