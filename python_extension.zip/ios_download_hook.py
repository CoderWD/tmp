"""将 yt-dlp HttpFD / HlsFD 下载委托给 iOS 后台 URLSession。"""

from __future__ import annotations

import os
import time

from ios_debug_log import log

_HOOK_INSTALLED = False
_ORIGINAL_HTTP_REAL_DOWNLOAD = None
_ORIGINAL_HLS_REAL_DOWNLOAD = None


def should_enable_ios_download_hook(force: bool | None = None) -> bool:
    if force is not None:
        return force
    try:
        from ios_js_evaluator import is_ios_platform

        return is_ios_platform()
    except Exception:  # noqa: BLE001
        return False


def _should_delegate_http(fd, filename: str, info_dict: dict) -> bool:
    try:
        from ios_download_bridge import is_bridge_available
    except Exception:  # noqa: BLE001
        return False

    if not is_bridge_available():
        return False
    if fd.params.get('test'):
        return False
    if filename == '-' or info_dict.get('url') in ('-', 'pipe:'):
        return False
    protocol = info_dict.get('protocol') or ''
    if protocol in ('rtmp_ffmpeg', 'live_ffmpeg'):
        return False
    url = str(info_dict.get('url') or '')
    if not url.startswith(('http://', 'https://')):
        return False
    return True


def _should_delegate_hls(fd, filename: str, info_dict: dict) -> bool:
    if not _should_delegate_http(fd, filename, info_dict):
        return False
    if info_dict.get('is_live'):
        return False
    protocol = info_dict.get('protocol') or ''
    if protocol != 'm3u8_native':
        return False
    if info_dict.get('ext') == 'vtt':
        return False

    manifest = str(info_dict.get('hls_media_playlist_data') or '')
    if manifest:
        upper = manifest.upper()
        if '#EXT-X-KEY:METHOD=AES-128' in upper:
            return False
        if '#EXT-X-BYTERANGE' in upper:
            return False
        try:
            from yt_dlp.downloader.hls import HlsFD

            if HlsFD._has_drm(manifest):
                return False
        except Exception:  # noqa: BLE001
            pass
    return True


def _make_transfer_id(filename: str) -> str:
    from ios_download_bridge import get_active_task_id

    task_id = get_active_task_id() or 'task'
    base = os.path.basename(filename or 'file')
    return f'{task_id}:{base}'


def _headers_dict(info_dict: dict) -> dict:
    headers = info_dict.get('http_headers') or {}
    if hasattr(headers, 'items'):
        return {str(k): str(v) for k, v in headers.items()}
    return dict(headers)


def _request_data(info_dict: dict):
    value = info_dict.get('request_data')
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode('utf-8', errors='replace')
    return str(value)


def _report_finished(fd, filename: str, info_dict: dict, tmpfilename: str, start: float, size: int) -> None:
    fd.try_rename(tmpfilename, filename)
    fd._hook_progress(
        {
            'status': 'finished',
            'downloaded_bytes': size,
            'total_bytes': size,
            'filename': filename,
            'tmpfilename': tmpfilename,
            'elapsed': time.time() - start,
            'ctx_id': info_dict.get('ctx_id'),
        },
        info_dict,
    )


def _is_user_cancelled(exc: BaseException) -> bool:
    try:
        from ios_progress_bridge import is_cancelled
        from ios_download_bridge import get_active_task_id

        if is_cancelled(get_active_task_id() or ''):
            return True
    except Exception:  # noqa: BLE001
        pass
    return 'cancel' in str(exc).lower()


def _ios_http_download(fd, filename: str, info_dict: dict) -> bool:
    from ios_download_bridge import download_via_bridge, get_active_task_id

    transfer_id = _make_transfer_id(filename)
    tmpfilename = fd.temp_name(filename)
    resume_len = 0
    if fd.params.get('continuedl', True) and os.path.isfile(tmpfilename):
        resume_len = os.path.getsize(tmpfilename)

    fd.report_destination(filename)
    start = time.time()

    result = download_via_bridge(
        {
            'kind': 'http',
            'transfer_id': transfer_id,
            'task_id': get_active_task_id(),
            'url': info_dict['url'],
            'headers': _headers_dict(info_dict),
            'destination_path': os.path.abspath(tmpfilename),
            'resume_from': resume_len,
            'background': True,
            'request_data': _request_data(info_dict),
        }
    )

    if not result.get('ok'):
        error = result.get('error') or 'background download failed'
        log('download_hook', f'background download failed: {error}')
        raise OSError(1, error)

    downloaded_bytes = int(result.get('downloaded_bytes') or 0)
    _report_finished(fd, filename, info_dict, tmpfilename, start, downloaded_bytes)
    return True


def _ios_hls_download(fd, filename: str, info_dict: dict) -> bool:
    from ios_download_bridge import download_via_bridge, get_active_task_id

    transfer_id = _make_transfer_id(filename)
    tmpfilename = fd.temp_name(filename)
    fd.report_destination(filename)
    start = time.time()

    log('download_hook', f'delegate HlsFD -> background manifest={info_dict.get("url")!r}')
    result = download_via_bridge(
        {
            'kind': 'hls',
            'transfer_id': transfer_id,
            'task_id': get_active_task_id(),
            'manifest_url': info_dict['url'],
            'headers': _headers_dict(info_dict),
            'destination_path': os.path.abspath(tmpfilename),
            'resume_from': 0,
            'background': True,
        }
    )

    if not result.get('ok'):
        error = result.get('error') or 'background HLS download failed'
        log('download_hook', f'background HLS failed: {error}')
        raise OSError(1, error)

    downloaded_bytes = int(result.get('downloaded_bytes') or 0)
    _report_finished(fd, filename, info_dict, tmpfilename, start, downloaded_bytes)
    return True


def apply_ios_download_hook(force: bool | None = None) -> bool:
    global _HOOK_INSTALLED, _ORIGINAL_HTTP_REAL_DOWNLOAD, _ORIGINAL_HLS_REAL_DOWNLOAD

    if _HOOK_INSTALLED:
        return True
    if not should_enable_ios_download_hook(force):
        return False

    from yt_dlp.downloader.hls import HlsFD
    from yt_dlp.downloader.http import HttpFD

    _ORIGINAL_HTTP_REAL_DOWNLOAD = HttpFD.real_download
    _ORIGINAL_HLS_REAL_DOWNLOAD = HlsFD.real_download

    def patched_http_real_download(self, filename, info_dict):
        if _should_delegate_http(self, filename, info_dict):
            try:
                log('download_hook', f'delegate HttpFD -> background url={info_dict.get("url")!r}')
                return _ios_http_download(self, filename, info_dict)
            except Exception as exc:  # noqa: BLE001
                if _is_user_cancelled(exc):
                    raise
                log('download_hook', f'background HTTP error, fallback native: {exc}')
        return _ORIGINAL_HTTP_REAL_DOWNLOAD(self, filename, info_dict)

    def patched_hls_real_download(self, filename, info_dict):
        if _should_delegate_hls(self, filename, info_dict):
            try:
                return _ios_hls_download(self, filename, info_dict)
            except Exception as exc:  # noqa: BLE001
                if _is_user_cancelled(exc):
                    raise
                log('download_hook', f'background HLS error, fallback native: {exc}')
        return _ORIGINAL_HLS_REAL_DOWNLOAD(self, filename, info_dict)

    HttpFD.real_download = patched_http_real_download
    HlsFD.real_download = patched_hls_real_download
    _HOOK_INSTALLED = True
    log('download_hook', 'apply_ios_download_hook installed (HttpFD + HlsFD)')
    return True


def is_hook_installed() -> bool:
    return _HOOK_INSTALLED
