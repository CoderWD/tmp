"""Cookie 规范化：Swift Netscape 字符串 → yt-dlp cookiefile / HTTP Cookie 头。

优先 cookiefile（域名匹配更准确）；无法落盘时再回退 http_headers。
"""

from __future__ import annotations

import os
import uuid
from typing import Optional
from urllib.parse import urlparse

NETSCAPE_HEADER = "# Netscape HTTP Cookie File"


def _looks_like_netscape_row(line: str) -> bool:
    if not line or line.startswith("#"):
        return False
    parts = line.split("\t")
    return len(parts) >= 7


def _cookie_header_pairs(raw: str) -> list[tuple[str, str]]:
    """解析 `a=b; c=d` 风格，忽略空段。"""
    pairs: list[tuple[str, str]] = []
    for piece in raw.split(";"):
        piece = piece.strip()
        if not piece or "=" not in piece:
            continue
        name, value = piece.split("=", 1)
        name = name.strip()
        if not name:
            continue
        pairs.append((name, value.strip()))
    return pairs


def _domain_for_url(url: str | None) -> str:
    if not url:
        return ""
    host = urlparse(url).hostname or ""
    if not host:
        return ""
    # Netscape：前导点表示包含子域
    return host if host.startswith(".") else f".{host}"


def normalize_netscape_cookie_text(cookie_str: str | None, url: str | None = None) -> str | None:
    """
    将任意常见 cookie 输入规范为 Netscape cookie file 全文。
    仅有表头 / 空内容 → None。
    """
    if cookie_str is None:
        return None
    text = str(cookie_str).strip()
    if not text:
        return None

    lines = text.splitlines()
    if not lines:
        return None

    # 已是 Netscape
    if lines[0].strip() == NETSCAPE_HEADER:
        body = [ln for ln in lines[1:] if _looks_like_netscape_row(ln.strip())]
        if not body:
            return None
        return NETSCAPE_HEADER + "\n" + "\n".join(body) + "\n"

    # 无表头但已是 tab 行
    tab_body = [ln for ln in lines if _looks_like_netscape_row(ln.strip())]
    if tab_body:
        return NETSCAPE_HEADER + "\n" + "\n".join(tab_body) + "\n"

    # Cookie 请求头风格 → 合成 Netscape（依赖 URL 域名）
    pairs = _cookie_header_pairs(text if "\t" not in text else "")
    if not pairs:
        # 可能整段是去掉表头后的正文但用空格/其它分隔失败
        return None

    domain = _domain_for_url(url)
    if not domain:
        return None

    out = [NETSCAPE_HEADER]
    for name, value in pairs:
        # domain, includeSubdomains, path, secure, expiry, name, value
        out.append(f"{domain}\tTRUE\t/\tFALSE\t0\t{name}\t{value}")
    return "\n".join(out) + "\n"


def cookie_header_from_raw(cookie_str: str | None) -> str | None:
    """无法写 cookiefile 时的备用：`name=value; ...`。"""
    if not cookie_str or not str(cookie_str).strip():
        return None
    text = str(cookie_str).strip()
    if text.startswith(NETSCAPE_HEADER) or "\t" in text:
        pairs: list[str] = []
        for line in text.splitlines():
            if not _looks_like_netscape_row(line.strip()):
                continue
            parts = line.split("\t")
            if len(parts) >= 7:
                pairs.append(f"{parts[5]}={parts[6]}")
        return "; ".join(pairs) if pairs else None
    pairs = _cookie_header_pairs(text)
    if not pairs:
        return None
    return "; ".join(f"{n}={v}" for n, v in pairs)


def write_cookiefile(
    cookie_str: str | None,
    cache_dir: str,
    url: str | None = None,
) -> Optional[str]:
    """写入唯一临时 cookiefile，返回路径；无可写内容则 None。"""
    normalized = normalize_netscape_cookie_text(cookie_str, url=url)
    if not normalized:
        return None
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"cookies_{os.getpid()}_{uuid.uuid4().hex[:12]}.txt")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(normalized)
    return path


def apply_cookies_to_ydl_opts(
    ydl_opts: dict,
    cookie_str: str | None,
    cache_dir: str,
    url: str | None = None,
) -> Optional[str]:
    """
    将 cookies 写入 ydl_opts。
    返回 cookiefile 路径（调用方负责清理）；若用了 http_headers 回退则返回 None。
    """
    path = write_cookiefile(cookie_str, cache_dir, url=url)
    if path:
        ydl_opts["cookiefile"] = path
        return path

    header = cookie_header_from_raw(cookie_str)
    if header:
        headers = dict(ydl_opts.get("http_headers") or {})
        headers["Cookie"] = header
        ydl_opts["http_headers"] = headers
    return None


def cleanup_cookiefile(path: str | None) -> None:
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
