"""iOS JavaScript 执行辅助（版本探测 + 非 EJS 子进程 JS 回退）。"""

from __future__ import annotations

import re
import sys

_JS_RUNTIME_NAMES = frozenset({
    'node', 'nodejs', 'deno', 'bun', 'qjs', 'quickjs', 'quickjs-ng',
})

_FAKE_VERSION_OUTPUT = {
    'node': 'v22.11.0\n',
    'deno': 'deno 2.3.0 (stable, release, aarch64-apple-ios)\n',
    'bun': '1.2.11\n',
    'qjs': 'QuickJS-ng version 0.12.0\n',
    'quickjs': 'QuickJS-ng version 0.12.0\n',
}


def _normalize_program_name(name: str) -> str:
    base = name.lower()
    if base.endswith('.exe'):
        return base[:-4]
    return base


def is_js_runtime_name(name: str) -> bool:
    base = _normalize_program_name(name)
    if base in _JS_RUNTIME_NAMES:
        return True
    return base.startswith('quickjs')


def fake_version_output(program: str) -> str | None:
    base = _normalize_program_name(program)
    if base in ('qjs', 'quickjs', 'quickjs-ng'):
        return _FAKE_VERSION_OUTPUT['qjs']
    return _FAKE_VERSION_OUTPUT.get(base)


def is_version_probe(argv: list[str]) -> bool:
    if len(argv) < 2:
        return False
    flags = {arg.lower() for arg in argv[1:]}
    if '--version' in flags:
        return True
    if '--help' in flags and is_js_runtime_name(argv[0]):
        return True
    if argv[1:] == ['-h'] and is_js_runtime_name(argv[0]):
        return True
    return False


def is_js_stdin_execution(argv: list[str]) -> bool:
    return bool(argv) and argv[-1] == '-' and is_js_runtime_name(argv[0])


def is_quickjs_script_execution(argv: list[str]) -> bool:
    return (
        len(argv) >= 3
        and is_js_runtime_name(argv[0])
        and argv[1] == '--script'
    )


def _eval_with_quickjs(source: str) -> tuple[str, str]:
    import quickjs  # type: ignore[import-untyped]

    output: list[str] = []

    def _log(message: str) -> None:
        output.append(message)

    ctx = quickjs.Context()
    ctx.add_callable('__ios_console_log', _log)
    ctx.eval(
        'if (typeof console === "undefined") {'
        '  var console = { log: function(msg) { __ios_console_log(String(msg)); } };'
        '}'
    )
    ctx.eval(source, filename='yt-dlp-jsc.js')
    if not output:
        raise RuntimeError('JS runtime produced no console output')
    return output[-1], ''


def evaluate_javascript(source: str) -> tuple[str, str]:
    """执行 JS：优先 Swift 桥接，桌面测试回退 quickjs。"""
    from ios_debug_log import log

    if not source or not source.strip():
        raise RuntimeError('empty JavaScript source')

    try:
        from ios_js_bridge import evaluate_via_bridge, is_bridge_available

        log('js_evaluator', f'evaluate_javascript bridge_available={is_bridge_available()}')
        if is_bridge_available():
            return evaluate_via_bridge(source)
    except ImportError:
        log('js_evaluator', 'ios_js_bridge not importable, trying quickjs fallback')

    try:
        return _eval_with_quickjs(source)
    except ImportError:
        raise RuntimeError(
            'No JS engine available. On iOS register Swift runner via PythonJSBridge; '
            'on desktop install quickjs for tests.'
        ) from None


def evaluate_script_file(path: str) -> tuple[str, str]:
    with open(path, encoding='utf-8') as handle:
        source = handle.read()
    return evaluate_javascript(source)


def clean_js_runtime_stderr(stderr: str) -> str:
    if not stderr:
        return ''
    lines = []
    for line in stderr.splitlines():
        if re.match(r'^\[stdin\]:', line):
            continue
        if re.match(r'^var jsc', line):
            continue
        if line == '(Use `node --trace-uncaught ...` to show where the exception was thrown)':
            continue
        if re.match(r'^Node\.js v\d+\.\d+\.\d+$', line):
            continue
        if re.match(r'^Bun v\d+\.\d+\.\d+ \(', line):
            continue
        lines.append(line)
    return '\n'.join(lines)


def is_ios_platform() -> bool:
    return sys.platform in {'ios', 'tvos', 'visionos', 'watchos'}
